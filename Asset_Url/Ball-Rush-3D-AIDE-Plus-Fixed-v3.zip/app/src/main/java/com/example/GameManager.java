package com.example;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

/**
 * Central Game State Machine and Core Logic Manager for Ball Rush 3D.
 */
public class GameManager {

    public enum State {
        MENU,
        PLAYING,
        PAUSED,
        GAME_OVER
    }

    public interface StateListener {
        void onStateChanged(State newState);
        void onScoreUpdated(int score, int best, int coins);
        void onGameOver(int score, int best, int coins, boolean isNewBest);
    }

    private State currentState = State.MENU;
    private Player player;
    private Track track;
    private ScoreManager scoreManager;
    private ParticleSystem particles;
    private EnvironmentConfig currentEnvironment;
    private StateListener stateListener;
    private Handler mainHandler;

    private float gameOverTimer = 0.0f;
    private float menuTime = 0.0f;
    private boolean showTouchControls = true;

    public GameManager(Context context) {
        mainHandler = new Handler(Looper.getMainLooper());
        player = new Player();
        track = new Track();
        scoreManager = new ScoreManager(context);
        particles = new ParticleSystem();
        currentEnvironment = EnvironmentConfig.get(EnvironmentConfig.Theme.SKY_CITY);
    }

    public void setStateListener(StateListener listener) {
        this.stateListener = listener;
    }

    public void startGame() {
        player.reset();
        track.reset();
        scoreManager.resetGame();
        particles.clear();
        gameOverTimer = 0.0f;
        setState(State.PLAYING);
        SoundManager.getInstance().startMusic();
    }

    public void pauseGame() {
        if (currentState == State.PLAYING) {
            setState(State.PAUSED);
        }
    }

    public void resumeGame() {
        if (currentState == State.PAUSED) {
            setState(State.PLAYING);
        }
    }

    public void restartGame() {
        startGame();
    }

    public void goToMenu() {
        player.reset();
        track.reset();
        particles.clear();
        setState(State.MENU);
    }

    public void setEnvironment(EnvironmentConfig.Theme theme) {
        this.currentEnvironment = EnvironmentConfig.get(theme);
    }

    public EnvironmentConfig getCurrentEnvironment() {
        return currentEnvironment;
    }

    public void update(float dt) {
        particles.update(dt);

        switch (currentState) {
            case MENU:
                menuTime += dt;
                // Idle floating animation
                player.z = 0.0f;
                player.x = 0.0f;
                player.y = Player.GROUND_Y + (float) Math.sin(menuTime * 2.0) * 0.15f;
                player.ringAngle += 60.0f * dt;
                break;

            case PLAYING:
                float prevZ = player.z;

                // Speed increases with distance: starting at 16.0f up to 34.0f
                player.forwardSpeed = 16.0f + Math.min(18.0f, player.z * 0.012f);

                player.update(dt, particles);
                track.update(dt, player.z);

                // Add distance score
                float deltaZ = player.z - prevZ;
                if (deltaZ > 0) {
                    scoreManager.addDistance(deltaZ);
                }

                // Check collisions
                boolean hit = CollisionManager.checkCollisions(player, track, scoreManager, particles);
                if (hit || player.isDead) {
                    gameOverTimer = 0.9f; // wait 0.9s for dramatic crash / camera effect
                }

                // Notify score update to UI
                if (stateListener != null) {
                    mainHandler.post(new Runnable() {
                        @Override
                        public void run() {
                        if (stateListener != null) {
                            stateListener.onScoreUpdated(scoreManager.getCurrentScore(),
                                    scoreManager.getBestScore(), scoreManager.getCurrentCoins());
                        }
                    }});
                }

                if (player.isDead) {
                    gameOverTimer -= dt;
                    if (gameOverTimer <= 0.0f) {
                        scoreManager.saveScores();
                        setState(State.GAME_OVER);
                        final int score = scoreManager.getCurrentScore();
                        final int best = scoreManager.getBestScore();
                        final int coins = scoreManager.getCurrentCoins();
                        final boolean isNewBest = scoreManager.isNewBest();
                        mainHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            if (stateListener != null) {
                                stateListener.onGameOver(score, best, coins, isNewBest);
                            }
                        }});
                    }
                }
                break;

            case PAUSED:
                break;

            case GAME_OVER:
                break;
        }
    }

    private void setState(State state) {
        this.currentState = state;
        if (stateListener != null) {
            mainHandler.post(new Runnable() {
                        @Override
                        public void run() {
                if (stateListener != null) {
                    stateListener.onStateChanged(currentState);
                }
            }});
        }
    }

    public State getCurrentState() {
        return currentState;
    }

    public Player getPlayer() {
        return player;
    }

    public Track getTrack() {
        return track;
    }

    public ScoreManager getScoreManager() {
        return scoreManager;
    }

    public ParticleSystem getParticles() {
        return particles;
    }

    public boolean isShowTouchControls() {
        return showTouchControls;
    }

    public void setShowTouchControls(boolean show) {
        this.showTouchControls = show;
    }
}
