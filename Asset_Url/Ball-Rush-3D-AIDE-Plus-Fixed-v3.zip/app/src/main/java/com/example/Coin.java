package com.example;

/**
 * 3D Collectible Gold Coin entity.
 * Rotates continuously with golden metallic shine and particle pickup effect.
 */
public class Coin {
    public static final float RADIUS = 0.5f;

    public float x = 0.0f;
    public float y = 0.8f;
    public float z = 0.0f;

    public float rotY = 0.0f;
    public float bobTime = 0.0f;
    public float baseY = 0.8f;

    public boolean active = true;
    public boolean collected = false;

    public void init(float x, float y, float z) {
        this.x = x;
        this.baseY = y;
        this.y = y;
        this.z = z;
        this.active = true;
        this.collected = false;
        this.rotY = (float) (Math.random() * 360.0);
        this.bobTime = (float) (Math.random() * Math.PI * 2.0);
    }

    public void update(float dt) {
        if (!active || collected) return;

        rotY += 180.0f * dt;
        if (rotY > 360.0f) rotY -= 360.0f;

        bobTime += dt * 3.5f;
        y = baseY + (float) Math.sin(bobTime) * 0.12f;
    }
}
