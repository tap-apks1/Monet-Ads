package com.example;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Procedural infinite track generator and obstacle/coin manager.
 * Ensures balanced difficulty progression and guaranteed navigable safe paths.
 */
public class Track {
    public static final float SEGMENT_LENGTH = 12.0f;
    public static final int MAX_ACTIVE_SEGMENTS = 18;
    public static final int MAX_OBSTACLES = 40;
    public static final int MAX_COINS = 80;

    private List<TrackSegment> segments = new ArrayList<>();
    private List<Obstacle> obstacles = new ArrayList<>();
    private List<Coin> coins = new ArrayList<>();

    // Background scenery elements (pillars / floating buildings)
    public static class SceneryObject {
        public float x, y, z;
        public float scaleX, scaleY, scaleZ;
        public float rotY;
        public boolean isFloatingIsland;
    }
    public List<SceneryObject> scenery = new ArrayList<>();

    private float nextZ = 0.0f;
    private Random random = new Random();
    private int segmentCount = 0;

    public Track() {
        // Pre-allocate pools
        for (int i = 0; i < MAX_ACTIVE_SEGMENTS; i++) {
            segments.add(new TrackSegment());
        }
        for (int i = 0; i < MAX_OBSTACLES; i++) {
            obstacles.add(new Obstacle());
        }
        for (int i = 0; i < MAX_COINS; i++) {
            coins.add(new Coin());
        }

        // Initialize scenery
        for (int i = 0; i < 30; i++) {
            SceneryObject sc = new SceneryObject();
            sc.x = (i % 2 == 0 ? -1 : 1) * (14.0f + random.nextFloat() * 22.0f);
            sc.y = (random.nextBoolean() ? 10.0f : -5.0f) + random.nextFloat() * 15.0f;
            sc.z = i * 15.0f;
            sc.scaleX = 3.0f + random.nextFloat() * 4.0f;
            sc.scaleY = 8.0f + random.nextFloat() * 25.0f;
            sc.scaleZ = 3.0f + random.nextFloat() * 4.0f;
            sc.rotY = random.nextFloat() * 360.0f;
            sc.isFloatingIsland = random.nextBoolean();
            scenery.add(sc);
        }

        reset();
    }

    public void reset() {
        nextZ = 0.0f;
        segmentCount = 0;

        for (TrackSegment seg : segments) seg.active = false;
        for (Obstacle obs : obstacles) obs.active = false;
        for (Coin c : coins) c.active = false;

        // Build initial safe starting run (first 3 segments)
        for (int i = 0; i < 5; i++) {
            spawnSegment(TrackSegment.SegmentType.NORMAL);
        }

        // Build ahead
        while (nextZ < 150.0f) {
            spawnNextProceduralSegment();
        }
    }

    public void update(float dt, float playerZ) {
        // Update active segments
        for (TrackSegment seg : segments) {
            if (seg.active) {
                seg.update(dt);
                // Recycle segments behind player
                if (seg.getZEnd() < playerZ - 20.0f) {
                    seg.active = false;
                }
            }
        }

        // Update active obstacles
        for (Obstacle obs : obstacles) {
            if (obs.active) {
                obs.update(dt);
                if (obs.z < playerZ - 15.0f) {
                    obs.active = false;
                }
            }
        }

        // Update active coins
        for (Coin c : coins) {
            if (c.active) {
                c.update(dt);
                if (c.z < playerZ - 15.0f) {
                    c.active = false;
                }
            }
        }

        // Update background scenery
        for (SceneryObject sc : scenery) {
            if (sc.z < playerZ - 30.0f) {
                sc.z += 30 * 15.0f;
                sc.x = (random.nextBoolean() ? -1 : 1) * (14.0f + random.nextFloat() * 22.0f);
            }
        }

        // Generate more track ahead
        while (nextZ < playerZ + 160.0f) {
            spawnNextProceduralSegment();
        }
    }

    private void spawnNextProceduralSegment() {
        segmentCount++;
        float progress = Math.min(1.0f, segmentCount / 60.0f); // difficulty ramp

        // Decide segment type
        float r = random.nextFloat();
        if (segmentCount > 6 && r < 0.16f) {
            // Gap segment
            spawnSegment(TrackSegment.SegmentType.GAP);
            // Spawn coin jump arc over gap
            spawnCoinArc(nextZ - SEGMENT_LENGTH * 0.5f, 0);
            return;
        } else if (segmentCount > 10 && r < 0.28f) {
            // Moving platform
            spawnSegment(TrackSegment.SegmentType.MOVING_PLATFORM);
            return;
        }

        // Normal segment with obstacles
        TrackSegment seg = spawnSegment(TrackSegment.SegmentType.NORMAL);
        if (seg == null) return;

        // Populate obstacles and coins
        float segCenterZ = seg.getZCenter();
        if (segmentCount > 3) {
            spawnObstaclePattern(segCenterZ, progress);
        } else {
            // Initial coins
            spawnCoinLine(segCenterZ, 0, 3);
        }
    }

    private TrackSegment spawnSegment(TrackSegment.SegmentType type) {
        TrackSegment seg = getFreeSegment();
        if (seg != null) {
            seg.init(type, nextZ, SEGMENT_LENGTH, 0.0f);
            nextZ += SEGMENT_LENGTH;
        }
        return seg;
    }

    private void spawnObstaclePattern(float centerZ, float difficulty) {
        int pattern = random.nextInt(5);
        int safeLane = random.nextInt(3) - 1; // -1, 0, 1

        switch (pattern) {
            case 0:
                // Single Block Obstacle in one lane, coins in other lanes
                int blockLane = (safeLane == 0) ? (random.nextBoolean() ? -1 : 1) : 0;
                spawnObstacle(Obstacle.Type.BLOCK, blockLane, centerZ);
                spawnCoinLine(centerZ, safeLane, 3);
                break;

            case 1:
                // Spike Ball in one lane, coin line over safe lane
                int spikeLane = safeLane == 1 ? -1 : (safeLane == -1 ? 1 : (random.nextBoolean() ? -1 : 1));
                spawnObstacle(Obstacle.Type.SPIKE_BALL, spikeLane, centerZ);
                spawnCoinLine(centerZ, safeLane, 3);
                break;

            case 2:
                // Double Block (leaving 1 safe lane)
                for (int l = -1; l <= 1; l++) {
                    if (l != safeLane) {
                        spawnObstacle(Obstacle.Type.BLOCK, l, centerZ);
                    }
                }
                spawnCoinLine(centerZ, safeLane, 3);
                break;

            case 3:
                // Moving Hammer
                spawnObstacle(Obstacle.Type.MOVING_HAMMER, 0, centerZ);
                spawnCoinZigZag(centerZ);
                break;

            case 4:
                // Laser barrier (low laser across lane)
                int laserLane = random.nextInt(3) - 1;
                spawnObstacle(Obstacle.Type.LASER, laserLane, centerZ);
                // Coins above laser to encourage jumping!
                spawnCoinArc(centerZ, laserLane);
                break;
        }
    }

    private void spawnObstacle(Obstacle.Type type, int lane, float z) {
        Obstacle obs = getFreeObstacle();
        if (obs != null) {
            obs.init(type, lane, z, 0.0f);
        }
    }

    private void spawnCoinLine(float centerZ, int lane, int count) {
        float startZ = centerZ - (count - 1) * 1.5f * 0.5f;
        for (int i = 0; i < count; i++) {
            Coin c = getFreeCoin();
            if (c != null) {
                c.init(lane * Player.LANE_DISTANCE, 0.8f, startZ + i * 1.5f);
            }
        }
    }

    private void spawnCoinArc(float centerZ, int lane) {
        int count = 5;
        float startZ = centerZ - 2.5f;
        for (int i = 0; i < count; i++) {
            Coin c = getFreeCoin();
            if (c != null) {
                float t = (float) i / (count - 1);
                float y = 0.8f + (float) Math.sin(t * Math.PI) * 1.8f;
                c.init(lane * Player.LANE_DISTANCE, y, startZ + i * 1.25f);
            }
        }
    }

    private void spawnCoinZigZag(float centerZ) {
        int[] lanes = {-1, 0, 1, 0};
        for (int i = 0; i < lanes.length; i++) {
            Coin c = getFreeCoin();
            if (c != null) {
                c.init(lanes[i] * Player.LANE_DISTANCE, 0.8f, centerZ - 2.0f + i * 1.4f);
            }
        }
    }

    private TrackSegment getFreeSegment() {
        for (TrackSegment seg : segments) {
            if (!seg.active) return seg;
        }
        return null;
    }

    private Obstacle getFreeObstacle() {
        for (Obstacle obs : obstacles) {
            if (!obs.active) return obs;
        }
        return null;
    }

    private Coin getFreeCoin() {
        for (Coin c : coins) {
            if (!c.active) return c;
        }
        return null;
    }

    public List<TrackSegment> getSegments() {
        return segments;
    }

    public List<Obstacle> getObstacles() {
        return obstacles;
    }

    public List<Coin> getCoins() {
        return coins;
    }
}
