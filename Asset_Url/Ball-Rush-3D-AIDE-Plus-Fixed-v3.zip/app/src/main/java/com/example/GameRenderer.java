package com.example;

import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/**
 * OpenGL ES 2.0 3D Rendering Pipeline for Ball Rush 3D.
 * Features Phong specular lighting, neon bloom glow, dynamic ball shadows, and 3D camera.
 */
public class GameRenderer implements GLSurfaceView.Renderer {

    private GameManager gameManager;
    private long lastTimeNs = 0;

    // Shader Programs
    private int mainProgram;
    private int particleProgram;

    // Main Program Handles
    private int uMVPMatrixHandle;
    private int uMVMatrixHandle;
    private int uLightPosHandle;
    private int uColorHandle;
    private int uEmissionColorHandle;
    private int uSpecularPowerHandle;
    private int uUseLightingHandle;
    private int uFogColorHandle;
    private int uFogNearHandle;
    private int uFogFarHandle;
    private int aPositionHandle;
    private int aNormalHandle;

    // Particle Program Handles
    private int pMVPMatrixHandle;
    private int pPositionHandle;
    private int pColorHandle;

    // Matrices
    private float[] projectionMatrix = new float[16];
    private float[] viewMatrix = new float[16];
    private float[] modelMatrix = new float[16];
    private float[] mvMatrix = new float[16];
    private float[] mvpMatrix = new float[16];

    // Meshes
    private Mesh ballMesh;
    private Mesh ringMesh;
    private Mesh boxMesh;
    private Mesh coinMesh;
    private Mesh cylinderMesh;
    private Mesh shadowMesh;
    private Mesh quadMesh;

    // Camera smoothing
    private float camX = 0.0f;
    private float camY = 3.6f;
    private float camZ = -6.0f;
    private float camShake = 0.0f;
    private float menuOrbitAngle = 0.0f;

    public GameRenderer(GameManager gameManager) {
        this.gameManager = gameManager;
    }

    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        GLES20.glEnable(GLES20.GL_DEPTH_TEST);
        GLES20.glDepthFunc(GLES20.GL_LEQUAL);
        GLES20.glEnable(GLES20.GL_CULL_FACE);
        GLES20.glCullFace(GLES20.GL_BACK);

        // Alpha blending for neon glow and shadows
        GLES20.glEnable(GLES20.GL_BLEND);
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA);

        // Build Shaders
        mainProgram = ShaderHelper.createProgram(ShaderHelper.VERTEX_SHADER_CODE, ShaderHelper.FRAGMENT_SHADER_CODE);
        uMVPMatrixHandle = GLES20.glGetUniformLocation(mainProgram, "u_MVPMatrix");
        uMVMatrixHandle = GLES20.glGetUniformLocation(mainProgram, "u_MVMatrix");
        uLightPosHandle = GLES20.glGetUniformLocation(mainProgram, "u_LightPos");
        uColorHandle = GLES20.glGetUniformLocation(mainProgram, "u_Color");
        uEmissionColorHandle = GLES20.glGetUniformLocation(mainProgram, "u_EmissionColor");
        uSpecularPowerHandle = GLES20.glGetUniformLocation(mainProgram, "u_SpecularPower");
        uUseLightingHandle = GLES20.glGetUniformLocation(mainProgram, "u_UseLighting");
        uFogColorHandle = GLES20.glGetUniformLocation(mainProgram, "u_FogColor");
        uFogNearHandle = GLES20.glGetUniformLocation(mainProgram, "u_FogNear");
        uFogFarHandle = GLES20.glGetUniformLocation(mainProgram, "u_FogFar");
        aPositionHandle = GLES20.glGetAttribLocation(mainProgram, "a_Position");
        aNormalHandle = GLES20.glGetAttribLocation(mainProgram, "a_Normal");

        particleProgram = ShaderHelper.createProgram(ShaderHelper.PARTICLE_VERTEX_SHADER, ShaderHelper.PARTICLE_FRAGMENT_SHADER);
        pMVPMatrixHandle = GLES20.glGetUniformLocation(particleProgram, "u_MVPMatrix");
        pPositionHandle = GLES20.glGetAttribLocation(particleProgram, "a_Position");
        pColorHandle = GLES20.glGetAttribLocation(particleProgram, "a_Color");

        // Build Geometries
        ballMesh = MeshGenerator.createSphere(Player.RADIUS, 24, 24);
        ringMesh = MeshGenerator.createTorusRing(Player.RADIUS + 0.04f, 0.07f, 24, 12);
        boxMesh = MeshGenerator.createCube(1.0f, 1.0f, 1.0f);
        coinMesh = MeshGenerator.createCylinder(Coin.RADIUS, 0.16f, 18);
        cylinderMesh = MeshGenerator.createCylinder(1.0f, 1.0f, 16);
        shadowMesh = MeshGenerator.createQuad(Player.RADIUS * 2.2f, Player.RADIUS * 2.2f);
        quadMesh = MeshGenerator.createQuad(1.0f, 1.0f);

        lastTimeNs = System.nanoTime();
    }

    @Override
    public void onSurfaceChanged(GL10 gl, int width, int height) {
        GLES20.glViewport(0, 0, width, height);
        float aspect = (float) width / (float) (height == 0 ? 1 : height);
        MatrixHelper.perspectiveM(projectionMatrix, 62.0f, aspect, 0.5f, 220.0f);
    }

    @Override
    public void onDrawFrame(GL10 gl) {
        long now = System.nanoTime();
        float dt = (now - lastTimeNs) / 1_000_000_000.0f;
        lastTimeNs = now;
        if (dt > 0.1f) dt = 0.1f; // Clamp delta time spikes

        // Update Game Logic
        gameManager.update(dt);

        EnvironmentConfig env = gameManager.getCurrentEnvironment();
        GLES20.glClearColor(env.clearColor[0], env.clearColor[1], env.clearColor[2], 1.0f);
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);

        // Update Camera
        Player player = gameManager.getPlayer();
        if (gameManager.getCurrentState() == GameManager.State.MENU) {
            menuOrbitAngle += dt * 0.4f;
            float camDist = 7.0f;
            float eyeX = (float) Math.sin(menuOrbitAngle) * camDist;
            float eyeZ = (float) -Math.cos(menuOrbitAngle) * camDist;
            float eyeY = 3.2f;
            MatrixHelper.setLookAtM(viewMatrix, eyeX, eyeY, eyeZ, 0.0f, 1.0f, 0.0f, 0.0f, 1.0f, 0.0f);
        } else {
            // Smooth Camera Follow
            float targetCamX = player.x * 0.65f;
            float targetCamY = Math.max(Player.GROUND_Y + 2.8f, player.y + 2.4f);
            float targetCamZ = player.z - 6.2f;

            camX += (targetCamX - camX) * Math.min(1.0f, dt * 10.0f);
            camY += (targetCamY - camY) * Math.min(1.0f, dt * 8.0f);
            camZ += (targetCamZ - camZ) * Math.min(1.0f, dt * 18.0f);

            // Screen shake
            if (player.isDead) {
                camShake = (float) ((Math.random() - 0.5) * 0.35);
            } else {
                camShake = 0.0f;
            }

            MatrixHelper.setLookAtM(viewMatrix,
                    camX + camShake, camY + camShake, camZ,
                    player.x * 0.4f, player.y + 0.5f, player.z + 12.0f,
                    0.0f, 1.0f, 0.0f);
        }

        // Setup Main Program Uniforms
        GLES20.glUseProgram(mainProgram);
        GLES20.glUniform4fv(uFogColorHandle, 1, env.fogColor, 0);
        GLES20.glUniform1f(uFogNearHandle, env.fogNear);
        GLES20.glUniform1f(uFogFarHandle, env.fogFar);
        GLES20.glUniform3f(uLightPosHandle,
                player.x + env.lightDir[0] * 20.0f,
                player.y + env.lightDir[1] * 25.0f,
                player.z + env.lightDir[2] * 20.0f);

        // 1. Render Background Scenery (Floating Skyscrapers / Islands)
        renderScenery(env);

        // 2. Render Track Platforms & Neon Borders
        renderTrack(env);

        // 3. Render Obstacles
        renderObstacles();

        // 4. Render Collectible Coins
        renderCoins();

        // 5. Render Dynamic Player Shadow & Glow
        renderShadow(player);

        // 6. Render Player Ball
        renderPlayer(player);

        // 7. Render Particles
        renderParticles();
    }

    private void renderScenery(EnvironmentConfig env) {
        for (Track.SceneryObject sc : gameManager.getTrack().scenery) {
            MatrixHelper.setIdentityM(modelMatrix);
            MatrixHelper.translateM(modelMatrix, sc.x, sc.y, sc.z);
            MatrixHelper.rotateM(modelMatrix, sc.rotY, 0.0f, 1.0f, 0.0f);
            MatrixHelper.scaleM(modelMatrix, sc.scaleX, sc.scaleY, sc.scaleZ);

            drawMesh(boxMesh, env.pillarColor, new float[]{0.0f, 0.0f, 0.0f, 0.0f}, 4.0f, true);
        }
    }

    private void renderTrack(EnvironmentConfig env) {
        for (TrackSegment seg : gameManager.getTrack().getSegments()) {
            if (!seg.active) continue;
            if (seg.type == TrackSegment.SegmentType.GAP) continue; // no platform in gap

            float offsetX = (seg.type == TrackSegment.SegmentType.MOVING_PLATFORM) ? seg.movingOffsetX : 0.0f;
            float zCenter = seg.getZCenter();

            // Main Track Platform Slab
            MatrixHelper.setIdentityM(modelMatrix);
            MatrixHelper.translateM(modelMatrix, offsetX, -0.5f + seg.yElevation, zCenter);
            MatrixHelper.scaleM(modelMatrix, seg.width, seg.height, seg.length);
            drawMesh(boxMesh, env.trackColor, new float[]{0.0f, 0.0f, 0.0f, 0.0f}, 12.0f, true);

            // Left Neon Edge Trim
            MatrixHelper.setIdentityM(modelMatrix);
            MatrixHelper.translateM(modelMatrix, offsetX - seg.width * 0.5f + 0.1f, 0.02f + seg.yElevation, zCenter);
            MatrixHelper.scaleM(modelMatrix, 0.18f, 0.06f, seg.length);
            drawMesh(boxMesh, env.trackTrimColor, env.trackTrimColor, 1.0f, false);

            // Right Neon Edge Trim
            MatrixHelper.setIdentityM(modelMatrix);
            MatrixHelper.translateM(modelMatrix, offsetX + seg.width * 0.5f - 0.1f, 0.02f + seg.yElevation, zCenter);
            MatrixHelper.scaleM(modelMatrix, 0.18f, 0.06f, seg.length);
            drawMesh(boxMesh, env.trackTrimColor, env.trackTrimColor, 1.0f, false);

            // Left Lane Divider Glow Strip
            MatrixHelper.setIdentityM(modelMatrix);
            MatrixHelper.translateM(modelMatrix, offsetX - Player.LANE_DISTANCE * 0.5f, 0.02f + seg.yElevation, zCenter);
            MatrixHelper.scaleM(modelMatrix, 0.06f, 0.02f, seg.length);
            drawMesh(boxMesh, new float[]{0.2f, 0.4f, 0.6f, 0.4f}, new float[]{0.0f, 0.2f, 0.3f, 0.0f}, 1.0f, false);

            // Right Lane Divider Glow Strip
            MatrixHelper.setIdentityM(modelMatrix);
            MatrixHelper.translateM(modelMatrix, offsetX + Player.LANE_DISTANCE * 0.5f, 0.02f + seg.yElevation, zCenter);
            MatrixHelper.scaleM(modelMatrix, 0.06f, 0.02f, seg.length);
            drawMesh(boxMesh, new float[]{0.2f, 0.4f, 0.6f, 0.4f}, new float[]{0.0f, 0.2f, 0.3f, 0.0f}, 1.0f, false);
        }
    }

    private void renderObstacles() {
        for (Obstacle obs : gameManager.getTrack().getObstacles()) {
            if (!obs.active) continue;

            switch (obs.type) {
                case BLOCK: {
                    // Dark metallic block body
                    MatrixHelper.setIdentityM(modelMatrix);
                    MatrixHelper.translateM(modelMatrix, obs.x, obs.y, obs.z);
                    MatrixHelper.scaleM(modelMatrix, obs.width, obs.height, obs.depth);
                    drawMesh(boxMesh, new float[]{0.08f, 0.08f, 0.12f, 1.0f}, new float[]{0.0f, 0.0f, 0.0f, 0.0f}, 16.0f, true);

                    // Red glowing neon border trim
                    MatrixHelper.setIdentityM(modelMatrix);
                    MatrixHelper.translateM(modelMatrix, obs.x, obs.y, obs.z);
                    MatrixHelper.scaleM(modelMatrix, obs.width + 0.04f, obs.height * 0.15f, obs.depth + 0.04f);
                    drawMesh(boxMesh, new float[]{1.0f, 0.15f, 0.25f, 1.0f}, new float[]{0.9f, 0.1f, 0.2f, 1.0f}, 1.0f, false);
                    break;
                }

                case SPIKE_BALL: {
                    // Center metallic sphere
                    MatrixHelper.setIdentityM(modelMatrix);
                    MatrixHelper.translateM(modelMatrix, obs.x, obs.y, obs.z);
                    drawMesh(ballMesh, new float[]{0.15f, 0.15f, 0.18f, 1.0f}, new float[]{0.0f, 0.0f, 0.0f, 0.0f}, 24.0f, true);

                    // Glowing red spikes
                    float[] spikeColor = {1.0f, 0.2f, 0.2f, 1.0f};
                    for (int i = 0; i < 4; i++) {
                        MatrixHelper.setIdentityM(modelMatrix);
                        MatrixHelper.translateM(modelMatrix, obs.x, obs.y, obs.z);
                        MatrixHelper.rotateM(modelMatrix, i * 45.0f, 1.0f, 0.0f, 1.0f);
                        MatrixHelper.scaleM(modelMatrix, 0.2f, 1.9f, 0.2f);
                        drawMesh(boxMesh, spikeColor, spikeColor, 1.0f, false);
                    }
                    break;
                }

                case MOVING_HAMMER: {
                    // Hammer hinge / pivot at top
                    MatrixHelper.setIdentityM(modelMatrix);
                    MatrixHelper.translateM(modelMatrix, obs.x, obs.y, obs.z);
                    MatrixHelper.scaleM(modelMatrix, 0.6f, 0.6f, 0.6f);
                    drawMesh(boxMesh, new float[]{0.3f, 0.3f, 0.35f, 1.0f}, new float[]{0.0f, 0.0f, 0.0f, 0.0f}, 8.0f, true);

                    // Swing pendulum arm
                    double rad = Math.toRadians(obs.swingAngle);
                    float hammerArm = 3.5f;
                    float headX = obs.x + (float) Math.sin(rad) * hammerArm;
                    float headY = obs.y - (float) Math.cos(rad) * hammerArm;

                    MatrixHelper.setIdentityM(modelMatrix);
                    MatrixHelper.translateM(modelMatrix, (obs.x + headX) * 0.5f, (obs.y + headY) * 0.5f, obs.z);
                    MatrixHelper.rotateM(modelMatrix, -obs.swingAngle, 0.0f, 0.0f, 1.0f);
                    MatrixHelper.scaleM(modelMatrix, 0.18f, hammerArm, 0.18f);
                    drawMesh(boxMesh, new float[]{0.2f, 0.25f, 0.3f, 1.0f}, new float[]{0.0f, 0.0f, 0.0f, 0.0f}, 4.0f, true);

                    // Heavy hammer head with neon glowing band
                    MatrixHelper.setIdentityM(modelMatrix);
                    MatrixHelper.translateM(modelMatrix, headX, headY, obs.z);
                    MatrixHelper.rotateM(modelMatrix, -obs.swingAngle, 0.0f, 0.0f, 1.0f);
                    MatrixHelper.scaleM(modelMatrix, 1.8f, 1.0f, 1.2f);
                    drawMesh(boxMesh, new float[]{0.12f, 0.12f, 0.16f, 1.0f}, new float[]{0.0f, 0.0f, 0.0f, 0.0f}, 16.0f, true);

                    // Glowing red hammer ring
                    MatrixHelper.setIdentityM(modelMatrix);
                    MatrixHelper.translateM(modelMatrix, headX, headY, obs.z);
                    MatrixHelper.rotateM(modelMatrix, -obs.swingAngle, 0.0f, 0.0f, 1.0f);
                    MatrixHelper.scaleM(modelMatrix, 1.84f, 0.25f, 1.24f);
                    drawMesh(boxMesh, new float[]{1.0f, 0.2f, 0.2f, 1.0f}, new float[]{1.0f, 0.2f, 0.2f, 1.0f}, 1.0f, false);
                    break;
                }

                case LASER: {
                    // Left laser emitter post
                    MatrixHelper.setIdentityM(modelMatrix);
                    MatrixHelper.translateM(modelMatrix, obs.x - 1.2f, obs.y, obs.z);
                    MatrixHelper.scaleM(modelMatrix, 0.25f, 1.2f, 0.25f);
                    drawMesh(boxMesh, new float[]{0.2f, 0.2f, 0.25f, 1.0f}, new float[]{0.0f, 0.0f, 0.0f, 0.0f}, 8.0f, true);

                    // Right laser emitter post
                    MatrixHelper.setIdentityM(modelMatrix);
                    MatrixHelper.translateM(modelMatrix, obs.x + 1.2f, obs.y, obs.z);
                    MatrixHelper.scaleM(modelMatrix, 0.25f, 1.2f, 0.25f);
                    drawMesh(boxMesh, new float[]{0.2f, 0.2f, 0.25f, 1.0f}, new float[]{0.0f, 0.0f, 0.0f, 0.0f}, 8.0f, true);

                    // Glowing pulsing laser beam
                    float alpha = 0.75f + obs.laserPulse * 0.25f;
                    float[] laserCol = {1.0f, 0.1f, 0.15f, alpha};
                    MatrixHelper.setIdentityM(modelMatrix);
                    MatrixHelper.translateM(modelMatrix, obs.x, obs.y, obs.z);
                    MatrixHelper.scaleM(modelMatrix, 2.35f, 0.12f, 0.12f);
                    drawMesh(boxMesh, laserCol, laserCol, 1.0f, false);
                    break;
                }
            }
        }
    }

    private void renderCoins() {
        for (Coin c : gameManager.getTrack().getCoins()) {
            if (!c.active || c.collected) continue;

            MatrixHelper.setIdentityM(modelMatrix);
            MatrixHelper.translateM(modelMatrix, c.x, c.y, c.z);
            MatrixHelper.rotateM(modelMatrix, c.rotY, 0.0f, 1.0f, 0.0f);
            MatrixHelper.rotateM(modelMatrix, 90.0f, 1.0f, 0.0f, 0.0f);

            // Gold shiny coin material
            float[] goldColor = {1.0f, 0.84f, 0.15f, 1.0f};
            float[] goldEmission = {0.4f, 0.32f, 0.05f, 1.0f};
            drawMesh(coinMesh, goldColor, goldEmission, 28.0f, true);
        }
    }

    private void renderShadow(Player player) {
        if (player.isDead && player.isFalling) return;

        // Shadow beneath ball
        float heightAboveGround = player.y - Player.GROUND_Y;
        float shadowAlpha = Math.max(0.0f, 0.65f - heightAboveGround * 0.18f);
        float shadowScale = 1.0f + heightAboveGround * 0.15f;

        if (shadowAlpha > 0.01f) {
            MatrixHelper.setIdentityM(modelMatrix);
            MatrixHelper.translateM(modelMatrix, player.x, 0.03f, player.z);
            MatrixHelper.scaleM(modelMatrix, shadowScale, 1.0f, shadowScale);
            drawMesh(shadowMesh, new float[]{0.0f, 0.0f, 0.0f, shadowAlpha},
                    new float[]{0.0f, 0.0f, 0.0f, 0.0f}, 1.0f, false);
        }
    }

    private void renderPlayer(Player player) {
        // Player Glossy Black Sphere
        MatrixHelper.setIdentityM(modelMatrix);
        MatrixHelper.translateM(modelMatrix, player.x, player.y, player.z);
        MatrixHelper.rotateM(modelMatrix, player.tiltZ, 0.0f, 0.0f, 1.0f);
        MatrixHelper.rotateM(modelMatrix, player.rollX, 1.0f, 0.0f, 0.0f);

        // Glossy black sphere with high specular shine
        float[] ballColor = {0.05f, 0.07f, 0.10f, 1.0f};
        float[] noEmission = {0.0f, 0.0f, 0.0f, 0.0f};
        drawMesh(ballMesh, ballColor, noEmission, 48.0f, true);

        // Glowing Blue/Cyan Neon Ring along equator
        float[] neonCyan = {0.0f, 0.95f, 1.0f, 1.0f};
        MatrixHelper.setIdentityM(modelMatrix);
        MatrixHelper.translateM(modelMatrix, player.x, player.y, player.z);
        MatrixHelper.rotateM(modelMatrix, player.tiltZ, 0.0f, 0.0f, 1.0f);
        MatrixHelper.rotateM(modelMatrix, player.rollX, 1.0f, 0.0f, 0.0f);
        MatrixHelper.rotateM(modelMatrix, player.ringAngle, 0.0f, 1.0f, 0.0f);
        drawMesh(ringMesh, neonCyan, neonCyan, 1.0f, false);

        // Second subtle orthogonal neon ring for 3D depth
        MatrixHelper.setIdentityM(modelMatrix);
        MatrixHelper.translateM(modelMatrix, player.x, player.y, player.z);
        MatrixHelper.rotateM(modelMatrix, player.tiltZ, 0.0f, 0.0f, 1.0f);
        MatrixHelper.rotateM(modelMatrix, player.rollX, 1.0f, 0.0f, 0.0f);
        MatrixHelper.rotateM(modelMatrix, 90.0f, 1.0f, 0.0f, 0.0f);
        drawMesh(ringMesh, new float[]{0.0f, 0.6f, 0.9f, 0.6f}, new float[]{0.0f, 0.5f, 0.8f, 0.6f}, 1.0f, false);
    }

    private void renderParticles() {
        GLES20.glUseProgram(particleProgram);
        MatrixHelper.multiplyMM(mvpMatrix, projectionMatrix, viewMatrix);
        GLES20.glUniformMatrix4fv(pMVPMatrixHandle, 1, false, mvpMatrix, 0);

        gameManager.getParticles().draw(pPositionHandle, pColorHandle);
    }

    private void drawMesh(Mesh mesh, float[] color, float[] emission, float specPower, boolean lighting) {
        MatrixHelper.multiplyMM(mvMatrix, viewMatrix, modelMatrix);
        MatrixHelper.multiplyMM(mvpMatrix, projectionMatrix, mvMatrix);

        GLES20.glUniformMatrix4fv(uMVMatrixHandle, 1, false, mvMatrix, 0);
        GLES20.glUniformMatrix4fv(uMVPMatrixHandle, 1, false, mvpMatrix, 0);

        GLES20.glUniform4fv(uColorHandle, 1, color, 0);
        GLES20.glUniform4fv(uEmissionColorHandle, 1, emission, 0);
        GLES20.glUniform1f(uSpecularPowerHandle, specPower);
        GLES20.glUniform1f(uUseLightingHandle, lighting ? 1.0f : 0.0f);

        mesh.draw(aPositionHandle, aNormalHandle);
    }
}
