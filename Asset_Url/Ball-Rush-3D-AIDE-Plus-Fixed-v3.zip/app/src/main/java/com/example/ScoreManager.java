package com.example;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Manages Score, Best High Score, and Coins for Ball Rush 3D.
 * Persists high scores locally with SharedPreferences.
 */
public class ScoreManager {
    private static final String PREFS_NAME = "BallRush3D_Prefs";
    private static final String KEY_BEST_SCORE = "key_best_score";
    private static final String KEY_TOTAL_COINS = "key_total_coins";

    private SharedPreferences prefs;
    private int currentScore = 0;
    private int bestScore = 0;
    private int currentCoins = 0;
    private int totalCoins = 0;
    private boolean isNewBest = false;

    public ScoreManager(Context context) {
        prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        bestScore = prefs.getInt(KEY_BEST_SCORE, 0);
        totalCoins = prefs.getInt(KEY_TOTAL_COINS, 0);
    }

    public void resetGame() {
        currentScore = 0;
        currentCoins = 0;
        isNewBest = false;
    }

    public void addDistance(float deltaDistance) {
        currentScore += (int) (deltaDistance * 1.5f);
        checkNewBest();
    }

    public void addCoin() {
        currentCoins++;
        totalCoins++;
        currentScore += 25; // 25 points per coin
        checkNewBest();
    }

    public void addObstacleClear() {
        currentScore += 15;
        checkNewBest();
    }

    private void checkNewBest() {
        if (currentScore > bestScore) {
            bestScore = currentScore;
            isNewBest = true;
        }
    }

    public void saveScores() {
        SharedPreferences.Editor editor = prefs.edit();
        if (currentScore >= bestScore) {
            editor.putInt(KEY_BEST_SCORE, bestScore);
        }
        editor.putInt(KEY_TOTAL_COINS, totalCoins);
        editor.apply();
    }

    public int getCurrentScore() {
        return currentScore;
    }

    public int getBestScore() {
        return bestScore;
    }

    public int getCurrentCoins() {
        return currentCoins;
    }

    public int getTotalCoins() {
        return totalCoins;
    }

    public boolean isNewBest() {
        return isNewBest;
    }
}
