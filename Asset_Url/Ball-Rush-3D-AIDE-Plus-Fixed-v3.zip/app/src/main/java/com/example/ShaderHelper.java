package com.example;

import android.opengl.GLES20;
import android.util.Log;

/**
 * Compiles and links OpenGL ES 2.0 shaders for 3D rendering in Ball Rush 3D.
 */
public class ShaderHelper {
    private static final String TAG = "ShaderHelper";

    // 3D Lit & Glow Vertex Shader
    public static final String VERTEX_SHADER_CODE =
            "uniform mat4 u_MVPMatrix;\n" +
            "uniform mat4 u_MVMatrix;\n" +
            "attribute vec4 a_Position;\n" +
            "attribute vec3 a_Normal;\n" +
            "varying vec3 v_Position;\n" +
            "varying vec3 v_Normal;\n" +
            "varying float v_Depth;\n" +
            "void main() {\n" +
            "    v_Position = vec3(u_MVMatrix * a_Position);\n" +
            "    v_Normal = vec3(u_MVMatrix * vec4(a_Normal, 0.0));\n" +
            "    gl_Position = u_MVPMatrix * a_Position;\n" +
            "    v_Depth = gl_Position.z;\n" +
            "}\n";

    // 3D Lit & Glow Fragment Shader
    public static final String FRAGMENT_SHADER_CODE =
            "precision mediump float;\n" +
            "uniform vec3 u_LightPos;\n" +
            "uniform vec4 u_Color;\n" +
            "uniform vec4 u_EmissionColor;\n" +
            "uniform float u_SpecularPower;\n" +
            "uniform float u_UseLighting;\n" +
            "uniform vec4 u_FogColor;\n" +
            "uniform float u_FogNear;\n" +
            "uniform float u_FogFar;\n" +
            "varying vec3 v_Position;\n" +
            "varying vec3 v_Normal;\n" +
            "varying float v_Depth;\n" +
            "void main() {\n" +
            "    vec4 finalColor = u_Color;\n" +
            "    if (u_UseLighting > 0.5) {\n" +
            "        vec3 norm = normalize(v_Normal);\n" +
            "        vec3 lightDir = normalize(u_LightPos - v_Position);\n" +
            "        float diff = max(dot(norm, lightDir), 0.0);\n" +
            "        vec3 diffuse = (0.35 + 0.65 * diff) * u_Color.rgb;\n" +
            "        vec3 viewDir = normalize(-v_Position);\n" +
            "        vec3 reflectDir = reflect(-lightDir, norm);\n" +
            "        float spec = pow(max(dot(viewDir, reflectDir), 0.0), u_SpecularPower);\n" +
            "        vec3 specular = vec3(spec * 0.8) * (u_SpecularPower > 1.0 ? 1.0 : 0.0);\n" +
            "        finalColor = vec4(diffuse + specular + u_EmissionColor.rgb, u_Color.a);\n" +
            "    } else {\n" +
            "        finalColor = u_Color + u_EmissionColor;\n" +
            "    }\n" +
            "    float fogFactor = clamp((v_Depth - u_FogNear) / (u_FogFar - u_FogNear), 0.0, 1.0);\n" +
            "    gl_FragColor = mix(finalColor, u_FogColor, fogFactor);\n" +
            "}\n";

    // Particle & Sky Gradient Vertex Shader
    public static final String PARTICLE_VERTEX_SHADER =
            "uniform mat4 u_MVPMatrix;\n" +
            "attribute vec4 a_Position;\n" +
            "attribute vec4 a_Color;\n" +
            "varying vec4 v_Color;\n" +
            "void main() {\n" +
            "    v_Color = a_Color;\n" +
            "    gl_Position = u_MVPMatrix * a_Position;\n" +
            "}\n";

    // Particle & Sky Gradient Fragment Shader
    public static final String PARTICLE_FRAGMENT_SHADER =
            "precision mediump float;\n" +
            "varying vec4 v_Color;\n" +
            "void main() {\n" +
            "    gl_FragColor = v_Color;\n" +
            "}\n";

    public static int compileShader(int type, String shaderCode) {
        int shader = GLES20.glCreateShader(type);
        if (shader != 0) {
            GLES20.glShaderSource(shader, shaderCode);
            GLES20.glCompileShader(shader);
            int[] compileStatus = new int[1];
            GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, compileStatus, 0);
            if (compileStatus[0] == 0) {
                Log.e(TAG, "Error compiling shader: " + GLES20.glGetShaderInfoLog(shader));
                GLES20.glDeleteShader(shader);
                shader = 0;
            }
        }
        return shader;
    }

    public static int createProgram(String vertexSource, String fragmentSource) {
        int vertexShader = compileShader(GLES20.GL_VERTEX_SHADER, vertexSource);
        int fragmentShader = compileShader(GLES20.GL_FRAGMENT_SHADER, fragmentSource);
        if (vertexShader == 0 || fragmentShader == 0) {
            return 0;
        }

        int program = GLES20.glCreateProgram();
        if (program != 0) {
            GLES20.glAttachShader(program, vertexShader);
            GLES20.glAttachShader(program, fragmentShader);
            GLES20.glLinkProgram(program);

            int[] linkStatus = new int[1];
            GLES20.glGetProgramiv(program, GLES20.GL_LINK_STATUS, linkStatus, 0);
            if (linkStatus[0] == 0) {
                Log.e(TAG, "Error linking program: " + GLES20.glGetProgramInfoLog(program));
                GLES20.glDeleteProgram(program);
                program = 0;
            }
        }
        return program;
    }
}
