package com.example;

/**
 * Manages lighting, fog, sky colors, and architectural themes for each environment.
 */
public class EnvironmentConfig {

    public enum Theme {
        SKY_CITY,
        DESERT_RUINS,
        NEON_NIGHT,
        LAVA_WORLD
    }

    public String name;
    public float[] clearColor = new float[4];
    public float[] skyTopColor = new float[4];
    public float[] skyBottomColor = new float[4];
    public float[] fogColor = new float[4];
    public float fogNear;
    public float fogFar;

    public float[] lightDir = new float[3];
    public float[] trackColor = new float[4];
    public float[] trackSideColor = new float[4];
    public float[] trackTrimColor = new float[4];
    public float[] pillarColor = new float[4];

    public static EnvironmentConfig get(Theme theme) {
        EnvironmentConfig config = new EnvironmentConfig();
        switch (theme) {
            case SKY_CITY:
            default:
                config.name = "Sky City";
                config.clearColor = new float[]{0.35f, 0.65f, 0.95f, 1.0f};
                config.skyTopColor = new float[]{0.15f, 0.45f, 0.85f, 1.0f};
                config.skyBottomColor = new float[]{0.75f, 0.88f, 1.0f, 1.0f};
                config.fogColor = new float[]{0.60f, 0.80f, 0.98f, 1.0f};
                config.fogNear = 45.0f;
                config.fogFar = 160.0f;
                config.lightDir = new float[]{0.4f, 0.8f, -0.4f};
                config.trackColor = new float[]{0.12f, 0.16f, 0.24f, 1.0f};
                config.trackSideColor = new float[]{0.06f, 0.08f, 0.14f, 1.0f};
                config.trackTrimColor = new float[]{0.0f, 0.85f, 1.0f, 1.0f};
                config.pillarColor = new float[]{0.18f, 0.25f, 0.38f, 1.0f};
                break;

            case DESERT_RUINS:
                config.name = "Desert Ruins";
                config.clearColor = new float[]{0.92f, 0.70f, 0.45f, 1.0f};
                config.skyTopColor = new float[]{0.85f, 0.52f, 0.25f, 1.0f};
                config.skyBottomColor = new float[]{0.98f, 0.85f, 0.60f, 1.0f};
                config.fogColor = new float[]{0.90f, 0.72f, 0.50f, 1.0f};
                config.fogNear = 40.0f;
                config.fogFar = 150.0f;
                config.lightDir = new float[]{0.6f, 0.6f, -0.3f};
                config.trackColor = new float[]{0.38f, 0.30f, 0.22f, 1.0f};
                config.trackSideColor = new float[]{0.22f, 0.16f, 0.10f, 1.0f};
                config.trackTrimColor = new float[]{1.0f, 0.65f, 0.10f, 1.0f};
                config.pillarColor = new float[]{0.45f, 0.36f, 0.26f, 1.0f};
                break;

            case NEON_NIGHT:
                config.name = "Neon Night";
                config.clearColor = new float[]{0.04f, 0.02f, 0.10f, 1.0f};
                config.skyTopColor = new float[]{0.02f, 0.01f, 0.08f, 1.0f};
                config.skyBottomColor = new float[]{0.18f, 0.05f, 0.30f, 1.0f};
                config.fogColor = new float[]{0.08f, 0.03f, 0.18f, 1.0f};
                config.fogNear = 35.0f;
                config.fogFar = 140.0f;
                config.lightDir = new float[]{0.2f, 0.9f, -0.3f};
                config.trackColor = new float[]{0.06f, 0.06f, 0.12f, 1.0f};
                config.trackSideColor = new float[]{0.02f, 0.02f, 0.05f, 1.0f};
                config.trackTrimColor = new float[]{0.85f, 0.10f, 0.95f, 1.0f};
                config.pillarColor = new float[]{0.09f, 0.07f, 0.18f, 1.0f};
                break;

            case LAVA_WORLD:
                config.name = "Lava World";
                config.clearColor = new float[]{0.15f, 0.02f, 0.02f, 1.0f};
                config.skyTopColor = new float[]{0.25f, 0.04f, 0.02f, 1.0f};
                config.skyBottomColor = new float[]{0.70f, 0.20f, 0.02f, 1.0f};
                config.fogColor = new float[]{0.30f, 0.06f, 0.02f, 1.0f};
                config.fogNear = 35.0f;
                config.fogFar = 135.0f;
                config.lightDir = new float[]{0.1f, 0.9f, -0.2f};
                config.trackColor = new float[]{0.10f, 0.08f, 0.08f, 1.0f};
                config.trackSideColor = new float[]{0.05f, 0.02f, 0.02f, 1.0f};
                config.trackTrimColor = new float[]{1.0f, 0.28f, 0.0f, 1.0f};
                config.pillarColor = new float[]{0.14f, 0.09f, 0.08f, 1.0f};
                break;
        }
        return config;
    }
}
