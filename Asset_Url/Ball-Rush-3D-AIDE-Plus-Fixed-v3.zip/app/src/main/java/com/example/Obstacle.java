package com.example;

/**
 * 3D Obstacle Entities with varied geometry and dynamic movement patterns.
 */
public class Obstacle {

    public enum Type {
        BLOCK,
        SPIKE_BALL,
        MOVING_HAMMER,
        LASER
    }

    public Type type = Type.BLOCK;
    public float x = 0.0f;
    public float y = 0.0f;
    public float z = 0.0f;

    public float width = 1.8f;
    public float height = 1.6f;
    public float depth = 1.2f;

    // Movement & animation
    public float animTime = 0.0f;
    public float swingSpeed = 3.0f;
    public float swingAngle = 0.0f;
    public float laserPulse = 0.0f;
    public int lane = 0; // -1, 0, 1

    public boolean active = true;
    public boolean cleared = false; // scored when passed

    public void init(Type type, int lane, float z, float baseY) {
        this.type = type;
        this.lane = lane;
        this.x = lane * Player.LANE_DISTANCE;
        this.z = z;
        this.active = true;
        this.cleared = false;
        this.animTime = (float) (Math.random() * Math.PI * 2.0);

        switch (type) {
            case BLOCK:
                this.width = 1.9f;
                this.height = 1.3f;
                this.depth = 1.0f;
                this.y = baseY + this.height * 0.5f;
                break;

            case SPIKE_BALL:
                this.width = 1.6f;
                this.height = 1.6f;
                this.depth = 1.6f;
                this.y = baseY + 0.8f;
                break;

            case MOVING_HAMMER:
                this.width = 2.0f;
                this.height = 2.0f;
                this.depth = 1.5f;
                this.y = baseY + 3.5f;
                this.swingSpeed = 2.8f;
                break;

            case LASER:
                this.width = 2.2f;
                this.height = 0.35f;
                this.depth = 0.35f;
                this.y = baseY + 0.7f; // low laser requiring jump or lane switch
                break;
        }
    }

    public void update(float dt) {
        if (!active) return;
        animTime += dt;

        if (type == Type.MOVING_HAMMER) {
            swingAngle = (float) Math.sin(animTime * swingSpeed) * 55.0f;
        } else if (type == Type.LASER) {
            laserPulse = (float) (Math.sin(animTime * 6.0) * 0.5 + 0.5);
        }
    }
}
