package com.example;

/**
 * Player Ball Entity in 3D space.
 * Glossy black sphere with glowing cyan neon ring, dynamic jumping, and lane transitions.
 */
public class Player {
    public static final float RADIUS = 0.8f;
    public static final float LANE_DISTANCE = 2.2f;
    public static final float GROUND_Y = 0.8f;
    public static final float BASE_GRAVITY = -36.0f;
    public static final float JUMP_VELOCITY = 13.5f;

    // Position in 3D world
    public float x = 0.0f;
    public float y = GROUND_Y;
    public float z = 0.0f;

    // Velocities
    public float vy = 0.0f;
    public float forwardSpeed = 16.0f;
    public float targetLaneX = 0.0f;
    public int currentLane = 0; // -1 = Left, 0 = Center, 1 = Right

    // Rotations (degrees)
    public float rollX = 0.0f;
    public float tiltZ = 0.0f;
    public float ringAngle = 0.0f;

    // State flags
    public boolean isGrounded = true;
    public boolean isJumping = false;
    public boolean isFalling = false;
    public boolean isDead = false;
    public float currentGroundY = GROUND_Y;

    // Trail timer
    private float trailTimer = 0.0f;

    public void reset() {
        x = 0.0f;
        y = GROUND_Y;
        z = 0.0f;
        vy = 0.0f;
        forwardSpeed = 16.0f;
        currentLane = 0;
        targetLaneX = 0.0f;
        rollX = 0.0f;
        tiltZ = 0.0f;
        ringAngle = 0.0f;
        isGrounded = true;
        isJumping = false;
        isFalling = false;
        isDead = false;
        currentGroundY = GROUND_Y;
        trailTimer = 0.0f;
    }

    public void moveLeft() {
        if (isDead || isFalling) return;
        if (currentLane > -1) {
            currentLane--;
            targetLaneX = currentLane * LANE_DISTANCE;
            SoundManager.getInstance().playLaneSwitch();
        }
    }

    public void moveRight() {
        if (isDead || isFalling) return;
        if (currentLane < 1) {
            currentLane++;
            targetLaneX = currentLane * LANE_DISTANCE;
            SoundManager.getInstance().playLaneSwitch();
        }
    }

    public void jump() {
        if (isDead || isFalling) return;
        if (isGrounded) {
            vy = JUMP_VELOCITY;
            isGrounded = false;
            isJumping = true;
            SoundManager.getInstance().playJump();
        }
    }

    public void update(float dt, ParticleSystem particles) {
        if (isDead) {
            // Death roll/fall
            if (isFalling) {
                vy += BASE_GRAVITY * dt;
                y += vy * dt;
            }
            return;
        }

        // Forward movement
        float deltaZ = forwardSpeed * dt;
        z += deltaZ;

        // Smooth sideways movement toward target lane
        float laneDiff = targetLaneX - x;
        float laneSpeed = 14.0f;
        x += laneDiff * Math.min(1.0f, dt * laneSpeed);

        // Tilt ball slightly into the turn
        tiltZ = -laneDiff * 8.0f;

        // Rolling rotation forward
        rollX += (deltaZ / RADIUS) * (180.0f / (float) Math.PI);
        if (rollX > 36000.0f) rollX -= 36000.0f;

        // Rotating neon ring
        ringAngle += 180.0f * dt;
        if (ringAngle > 360.0f) ringAngle -= 360.0f;

        // Vertical physics (jump & gravity)
        if (!isGrounded || isFalling) {
            vy += BASE_GRAVITY * dt;
            y += vy * dt;

            if (!isFalling && y <= currentGroundY) {
                // Landed on track
                y = currentGroundY;
                vy = 0.0f;
                isGrounded = true;
                isJumping = false;
                if (particles != null) {
                    particles.emitLanding(x, y - RADIUS, z);
                }
            }
        }

        // Falling below track into the abyss
        if (y < -3.5f && !isFalling) {
            triggerFall();
        }

        // Particle trail
        if (particles != null && isGrounded && !isFalling) {
            trailTimer += dt;
            if (trailTimer >= 0.035f) {
                trailTimer = 0.0f;
                particles.emitTrail(x, y - RADIUS * 0.5f, z);
            }
        }
    }

    public void triggerFall() {
        isFalling = true;
        isDead = true;
        SoundManager.getInstance().playGameOver();
    }

    public void triggerCrash(ParticleSystem particles) {
        isDead = true;
        if (particles != null) {
            particles.emitCrash(x, y, z);
        }
        SoundManager.getInstance().playCrash();
    }
}
