package com.example;

import android.opengl.GLES20;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.ShortBuffer;

/**
 * 3D Mesh wrapper holding geometry vertex and normal buffers.
 */
public class Mesh {
    private FloatBuffer vertexBuffer;
    private FloatBuffer normalBuffer;
    private ShortBuffer indexBuffer;
    private int numIndices;
    private int numVertices;
    private int drawMode = GLES20.GL_TRIANGLES;

    public Mesh(float[] vertices, float[] normals, short[] indices) {
        this.numVertices = vertices.length / 3;

        ByteBuffer vbb = ByteBuffer.allocateDirect(vertices.length * 4);
        vbb.order(ByteOrder.nativeOrder());
        vertexBuffer = vbb.asFloatBuffer();
        vertexBuffer.put(vertices);
        vertexBuffer.position(0);

        if (normals != null) {
            ByteBuffer nbb = ByteBuffer.allocateDirect(normals.length * 4);
            nbb.order(ByteOrder.nativeOrder());
            normalBuffer = nbb.asFloatBuffer();
            normalBuffer.put(normals);
            normalBuffer.position(0);
        }

        if (indices != null) {
            this.numIndices = indices.length;
            ByteBuffer ibb = ByteBuffer.allocateDirect(indices.length * 2);
            ibb.order(ByteOrder.nativeOrder());
            indexBuffer = ibb.asShortBuffer();
            indexBuffer.put(indices);
            indexBuffer.position(0);
        } else {
            this.numIndices = 0;
        }
    }

    public void setDrawMode(int mode) {
        this.drawMode = mode;
    }

    public void draw(int positionHandle, int normalHandle) {
        if (vertexBuffer == null) return;

        GLES20.glEnableVertexAttribArray(positionHandle);
        GLES20.glVertexAttribPointer(positionHandle, 3, GLES20.GL_FLOAT, false, 0, vertexBuffer);

        if (normalHandle >= 0 && normalBuffer != null) {
            GLES20.glEnableVertexAttribArray(normalHandle);
            GLES20.glVertexAttribPointer(normalHandle, 3, GLES20.GL_FLOAT, false, 0, normalBuffer);
        }

        if (indexBuffer != null && numIndices > 0) {
            GLES20.glDrawElements(drawMode, numIndices, GLES20.GL_UNSIGNED_SHORT, indexBuffer);
        } else {
            GLES20.glDrawArrays(drawMode, 0, numVertices);
        }

        GLES20.glDisableVertexAttribArray(positionHandle);
        if (normalHandle >= 0 && normalBuffer != null) {
            GLES20.glDisableVertexAttribArray(normalHandle);
        }
    }
}
