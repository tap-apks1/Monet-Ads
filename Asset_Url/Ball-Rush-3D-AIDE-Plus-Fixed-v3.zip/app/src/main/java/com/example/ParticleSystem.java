package com.example;

import android.opengl.GLES20;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.ArrayList;

/**
 * High-performance 3D particle emitter for coins, jumps, and collision explosions.
 */
public class ParticleSystem {
    private static final int MAX_PARTICLES = 250;

    public static class Particle {
        public float x, y, z;
        public float vx, vy, vz;
        public float r, g, b, a;
        public float size;
        public float life;
        public float maxLife;
        public boolean active;
    }

    private Particle[] particles = new Particle[MAX_PARTICLES];
    private float[] vertexData = new float[MAX_PARTICLES * 3];
    private float[] colorData = new float[MAX_PARTICLES * 4];
    private FloatBuffer vertexBuffer;
    private FloatBuffer colorBuffer;
    private int activeCount = 0;
    private java.util.Random random = new java.util.Random();

    public ParticleSystem() {
        for (int i = 0; i < MAX_PARTICLES; i++) {
            particles[i] = new Particle();
        }

        ByteBuffer vbb = ByteBuffer.allocateDirect(vertexData.length * 4);
        vbb.order(ByteOrder.nativeOrder());
        vertexBuffer = vbb.asFloatBuffer();

        ByteBuffer cbb = ByteBuffer.allocateDirect(colorData.length * 4);
        cbb.order(ByteOrder.nativeOrder());
        colorBuffer = cbb.asFloatBuffer();
    }

    public void update(float dt) {
        activeCount = 0;
        int vIdx = 0;
        int cIdx = 0;

        for (int i = 0; i < MAX_PARTICLES; i++) {
            Particle p = particles[i];
            if (!p.active) continue;

            p.life -= dt;
            if (p.life <= 0.0f) {
                p.active = false;
                continue;
            }

            p.x += p.vx * dt;
            p.y += p.vy * dt;
            p.z += p.vz * dt;
            p.vy -= 9.8f * dt; // gravity

            float alphaRatio = p.life / p.maxLife;

            vertexData[vIdx++] = p.x;
            vertexData[vIdx++] = p.y;
            vertexData[vIdx++] = p.z;

            colorData[cIdx++] = p.r;
            colorData[cIdx++] = p.g;
            colorData[cIdx++] = p.b;
            colorData[cIdx++] = p.a * alphaRatio;

            activeCount++;
        }

        if (activeCount > 0) {
            vertexBuffer.position(0);
            vertexBuffer.put(vertexData, 0, activeCount * 3);
            vertexBuffer.position(0);

            colorBuffer.position(0);
            colorBuffer.put(colorData, 0, activeCount * 4);
            colorBuffer.position(0);
        }
    }

    public void emitCoinPickup(float x, float y, float z) {
        for (int i = 0; i < 24; i++) {
            Particle p = getFreeParticle();
            if (p == null) break;
            p.active = true;
            p.x = x; p.y = y; p.z = z;
            float angle = (float) (random.nextDouble() * 2.0 * Math.PI);
            float speed = 2.0f + random.nextFloat() * 4.5f;
            p.vx = (float) Math.cos(angle) * speed;
            p.vy = 2.5f + random.nextFloat() * 4.0f;
            p.vz = (float) Math.sin(angle) * speed;
            p.r = 1.0f;
            p.g = 0.85f + random.nextFloat() * 0.15f;
            p.b = 0.1f;
            p.a = 1.0f;
            p.size = 8.0f;
            p.maxLife = 0.45f + random.nextFloat() * 0.35f;
            p.life = p.maxLife;
        }
    }

    public void emitTrail(float x, float y, float z) {
        Particle p = getFreeParticle();
        if (p == null) return;
        p.active = true;
        p.x = x + (random.nextFloat() - 0.5f) * 0.2f;
        p.y = y + (random.nextFloat() - 0.5f) * 0.2f;
        p.z = z - 0.3f;
        p.vx = (random.nextFloat() - 0.5f) * 0.3f;
        p.vy = (random.nextFloat() - 0.5f) * 0.3f;
        p.vz = -1.0f;
        p.r = 0.0f;
        p.g = 0.9f;
        p.b = 1.0f;
        p.a = 0.7f;
        p.size = 6.0f;
        p.maxLife = 0.25f;
        p.life = p.maxLife;
    }

    public void emitLanding(float x, float y, float z) {
        for (int i = 0; i < 16; i++) {
            Particle p = getFreeParticle();
            if (p == null) break;
            p.active = true;
            p.x = x; p.y = y + 0.05f; p.z = z;
            float angle = (float) (i * 2.0 * Math.PI / 16);
            float speed = 3.0f + random.nextFloat() * 2.0f;
            p.vx = (float) Math.cos(angle) * speed;
            p.vy = 0.5f + random.nextFloat() * 1.0f;
            p.vz = (float) Math.sin(angle) * speed;
            p.r = 0.0f;
            p.g = 0.85f;
            p.b = 1.0f;
            p.a = 0.8f;
            p.size = 7.0f;
            p.maxLife = 0.35f;
            p.life = p.maxLife;
        }
    }

    public void emitCrash(float x, float y, float z) {
        for (int i = 0; i < 40; i++) {
            Particle p = getFreeParticle();
            if (p == null) break;
            p.active = true;
            p.x = x; p.y = y; p.z = z;
            float speed = 3.0f + random.nextFloat() * 7.0f;
            float theta = (float) (random.nextDouble() * 2.0 * Math.PI);
            float phi = (float) (random.nextDouble() * Math.PI);
            p.vx = (float) (Math.sin(phi) * Math.cos(theta)) * speed;
            p.vy = (float) (Math.cos(phi)) * speed + 2.0f;
            p.vz = (float) (Math.sin(phi) * Math.sin(theta)) * speed;
            p.r = 1.0f;
            p.g = random.nextFloat() * 0.5f;
            p.b = 0.1f;
            p.a = 1.0f;
            p.size = 10.0f;
            p.maxLife = 0.6f + random.nextFloat() * 0.4f;
            p.life = p.maxLife;
        }
    }

    private Particle getFreeParticle() {
        for (int i = 0; i < MAX_PARTICLES; i++) {
            if (!particles[i].active) return particles[i];
        }
        return null;
    }

    public void draw(int posHandle, int colHandle) {
        if (activeCount <= 0) return;

        GLES20.glEnableVertexAttribArray(posHandle);
        GLES20.glVertexAttribPointer(posHandle, 3, GLES20.GL_FLOAT, false, 0, vertexBuffer);

        GLES20.glEnableVertexAttribArray(colHandle);
        GLES20.glVertexAttribPointer(colHandle, 4, GLES20.GL_FLOAT, false, 0, colorBuffer);

        GLES20.glDrawArrays(GLES20.GL_POINTS, 0, activeCount);

        GLES20.glDisableVertexAttribArray(posHandle);
        GLES20.glDisableVertexAttribArray(colHandle);
    }

    public void clear() {
        for (int i = 0; i < MAX_PARTICLES; i++) {
            particles[i].active = false;
        }
        activeCount = 0;
    }
}
