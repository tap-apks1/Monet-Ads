package com.example;

import java.util.List;

/**
 * 3D Physics Collision Engine.
 * Tests Player bounding sphere against Obstacles, Coins, and Track Gaps/Boundaries.
 */
public class CollisionManager {

    public static boolean checkCollisions(Player player, Track track, ScoreManager scoreManager, ParticleSystem particles) {
        if (player.isDead) return false;

        float px = player.x;
        float py = player.y;
        float pz = player.z;
        float pr = Player.RADIUS;

        // 1. Check Track Gaps & Falling off edges
        TrackSegment currentSegment = null;
        for (TrackSegment seg : track.getSegments()) {
            if (seg.active && seg.containsZ(pz)) {
                currentSegment = seg;
                break;
            }
        }

        if (currentSegment != null) {
            if (currentSegment.type == TrackSegment.SegmentType.GAP) {
                // In gap: player must be jumping high enough
                if (py <= Player.GROUND_Y + 0.05f) {
                    player.triggerFall();
                    return true;
                }
            } else if (currentSegment.type == TrackSegment.SegmentType.MOVING_PLATFORM) {
                // Moving platform bounds
                float minX = currentSegment.movingOffsetX - currentSegment.width * 0.5f;
                float maxX = currentSegment.movingOffsetX + currentSegment.width * 0.5f;
                if ((px < minX || px > maxX) && py <= Player.GROUND_Y + 0.05f) {
                    player.triggerFall();
                    return true;
                }
            } else {
                // Normal track bounds
                if ((px < -4.0f || px > 4.0f) && py <= Player.GROUND_Y + 0.05f) {
                    player.triggerFall();
                    return true;
                }
            }
        } else if (pz > 10.0f && py <= Player.GROUND_Y + 0.05f) {
            // Out of track bounds
            player.triggerFall();
            return true;
        }

        // 2. Check Coin Collectibles
        for (Coin c : track.getCoins()) {
            if (!c.active || c.collected) continue;

            float dx = px - c.x;
            float dy = py - c.y;
            float dz = pz - c.z;
            float distSq = dx * dx + dy * dy + dz * dz;
            float hitDist = pr + Coin.RADIUS + 0.2f;

            if (distSq <= hitDist * hitDist) {
                c.collected = true;
                c.active = false;
                scoreManager.addCoin();
                SoundManager.getInstance().playCoin();
                if (particles != null) {
                    particles.emitCoinPickup(c.x, c.y, c.z);
                }
            }
        }

        // 3. Check Obstacles
        for (Obstacle obs : track.getObstacles()) {
            if (!obs.active) continue;

            // Score obstacle cleared when passed
            if (!obs.cleared && pz > obs.z + 1.2f) {
                obs.cleared = true;
                scoreManager.addObstacleClear();
            }

            // Only check collision if close on Z
            if (Math.abs(pz - obs.z) > 2.0f) continue;

            switch (obs.type) {
                case BLOCK: {
                    float hw = obs.width * 0.5f;
                    float hh = obs.height * 0.5f;
                    float hd = obs.depth * 0.5f;

                    boolean xOverlap = Math.abs(px - obs.x) < (hw + pr * 0.75f);
                    boolean zOverlap = Math.abs(pz - obs.z) < (hd + pr * 0.75f);
                    boolean yOverlap = (py - pr) < (obs.y + hh);

                    if (xOverlap && zOverlap && yOverlap) {
                        player.triggerCrash(particles);
                        return true;
                    }
                    break;
                }

                case SPIKE_BALL: {
                    float dx = px - obs.x;
                    float dy = py - obs.y;
                    float dz = pz - obs.z;
                    float distSq = dx * dx + dy * dy + dz * dz;
                    float hitDist = pr + (obs.width * 0.5f) * 0.85f;

                    if (distSq <= hitDist * hitDist) {
                        player.triggerCrash(particles);
                        return true;
                    }
                    break;
                }

                case MOVING_HAMMER: {
                    // Hammer head swings on pendulum
                    double rad = Math.toRadians(obs.swingAngle);
                    float hammerArm = 3.5f;
                    float headX = obs.x + (float) Math.sin(rad) * hammerArm;
                    float headY = obs.y - (float) Math.cos(rad) * hammerArm;

                    float dx = px - headX;
                    float dy = py - headY;
                    float dz = pz - obs.z;
                    float distSq = dx * dx + dy * dy + dz * dz;
                    float hitDist = pr + 0.9f;

                    if (distSq <= hitDist * hitDist) {
                        player.triggerCrash(particles);
                        return true;
                    }
                    break;
                }

                case LASER: {
                    boolean inLane = Math.abs(px - obs.x) < 1.1f;
                    boolean inZ = Math.abs(pz - obs.z) < 0.6f;
                    boolean lowY = (py - pr) < (obs.y + 0.3f);

                    if (inLane && inZ && lowY) {
                        player.triggerCrash(particles);
                        return true;
                    }
                    break;
                }
            }
        }

        return false;
    }
}
