package com.example;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;

/**
 * Main Activity for Ball Rush 3D.
 * Configures full-screen immersive mode and coordinates GameView and GameOverlayView lifecycle.
 */
public class MainActivity extends Activity {

    private GameManager gameManager;
    private GameView gameView;
    private GameOverlayView overlayView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Configure Fullscreen Window
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        setImmersiveMode();

        // Initialize Core Systems
        gameManager = new GameManager(this);
        gameView = new GameView(this, gameManager);
        overlayView = new GameOverlayView(this, gameManager);

        // Build Root Layout
        FrameLayout rootLayout = new FrameLayout(this);
        rootLayout.addView(gameView);
        rootLayout.addView(overlayView);

        setContentView(rootLayout);
    }

    private void setImmersiveMode() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            View decorView = getWindow().getDecorView();
            int flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
            decorView.setSystemUiVisibility(flags);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            setImmersiveMode();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        setImmersiveMode();
        if (gameView != null) {
            gameView.onResume();
        }
        if (gameManager != null && gameManager.getCurrentState() == GameManager.State.PLAYING) {
            SoundManager.getInstance().startMusic();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (gameManager != null) {
            gameManager.pauseGame();
            gameManager.getScoreManager().saveScores();
        }
        if (gameView != null) {
            gameView.onPause();
        }
        SoundManager.getInstance().stopMusic();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (gameManager != null) {
            gameManager.getScoreManager().saveScores();
        }
        SoundManager.getInstance().release();
    }

    @Override
    public void onBackPressed() {
        if (gameManager != null) {
            if (gameManager.getCurrentState() == GameManager.State.PLAYING) {
                gameManager.pauseGame();
                return;
            } else if (gameManager.getCurrentState() == GameManager.State.PAUSED) {
                gameManager.goToMenu();
                return;
            } else if (gameManager.getCurrentState() == GameManager.State.GAME_OVER) {
                gameManager.goToMenu();
                return;
            }
        }
        super.onBackPressed();
    }
}
