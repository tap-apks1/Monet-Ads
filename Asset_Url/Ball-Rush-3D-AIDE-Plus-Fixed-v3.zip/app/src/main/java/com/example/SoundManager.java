package com.example;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.media.SoundPool;
import android.os.Build;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Procedural Audio Engine for Ball Rush 3D.
 * Synthesizes retro arcade sound effects and cyberpunk synth beats at runtime.
 */
public class SoundManager {
    private static SoundManager instance;
    private boolean soundEnabled = true;
    private boolean musicEnabled = true;

    private ExecutorService audioExecutor;
    private AudioTrack musicTrack;
    private volatile boolean isMusicPlaying = false;
    private Thread musicThread;

    public static synchronized SoundManager getInstance() {
        if (instance == null) {
            instance = new SoundManager();
        }
        return instance;
    }

    private SoundManager() {
        audioExecutor = Executors.newFixedThreadPool(2);
    }

    public void setSoundEnabled(boolean enabled) {
        this.soundEnabled = enabled;
    }

    public boolean isSoundEnabled() {
        return soundEnabled;
    }

    public void setMusicEnabled(boolean enabled) {
        this.musicEnabled = enabled;
        if (!enabled && isMusicPlaying) {
            stopMusic();
        } else if (enabled && !isMusicPlaying) {
            startMusic();
        }
    }

    public boolean isMusicEnabled() {
        return musicEnabled;
    }

    public void playJump() {
        if (!soundEnabled) return;
        audioExecutor.execute(new Runnable() {
            @Override
            public void run() {
            int sampleRate = 22050;
            int numSamples = (int) (0.16 * sampleRate);
            short[] buffer = new short[numSamples];
            for (int i = 0; i < numSamples; i++) {
                double t = (double) i / sampleRate;
                double freq = 220.0 + 550.0 * (t / 0.16); // rising frequency sweep
                double env = Math.sin(Math.PI * (t / 0.16));
                double sample = Math.sin(2.0 * Math.PI * freq * t) * env * 0.55;
                buffer[i] = (short) (sample * Short.MAX_VALUE);
            }
            playPcmBuffer(buffer, sampleRate);
        }});
    }

    public void playCoin() {
        if (!soundEnabled) return;
        audioExecutor.execute(new Runnable() {
            @Override
            public void run() {
            int sampleRate = 22050;
            int numSamples = (int) (0.18 * sampleRate);
            short[] buffer = new short[numSamples];
            for (int i = 0; i < numSamples; i++) {
                double t = (double) i / sampleRate;
                double freq = (t < 0.08) ? 987.77 : 1318.51; // B5 to E6 arpeggio chime
                double env = Math.exp(-t * 14.0);
                double sample = Math.sin(2.0 * Math.PI * freq * t) * env * 0.65;
                buffer[i] = (short) (sample * Short.MAX_VALUE);
            }
            playPcmBuffer(buffer, sampleRate);
        }});
    }

    public void playLaneSwitch() {
        if (!soundEnabled) return;
        audioExecutor.execute(new Runnable() {
            @Override
            public void run() {
            int sampleRate = 22050;
            int numSamples = (int) (0.09 * sampleRate);
            short[] buffer = new short[numSamples];
            for (int i = 0; i < numSamples; i++) {
                double t = (double) i / sampleRate;
                double freq = 440.0 - 150.0 * (t / 0.09);
                double env = Math.sin(Math.PI * (t / 0.09));
                double sample = Math.sin(2.0 * Math.PI * freq * t) * env * 0.40;
                buffer[i] = (short) (sample * Short.MAX_VALUE);
            }
            playPcmBuffer(buffer, sampleRate);
        }});
    }

    public void playCrash() {
        if (!soundEnabled) return;
        audioExecutor.execute(new Runnable() {
            @Override
            public void run() {
            int sampleRate = 22050;
            int numSamples = (int) (0.35 * sampleRate);
            short[] buffer = new short[numSamples];
            java.util.Random rnd = new java.util.Random();
            for (int i = 0; i < numSamples; i++) {
                double t = (double) i / sampleRate;
                double noise = (rnd.nextDouble() * 2.0 - 1.0);
                double boom = Math.sin(2.0 * Math.PI * (110.0 - 70.0 * t) * t);
                double env = Math.exp(-t * 7.0);
                double sample = (noise * 0.6 + boom * 0.4) * env * 0.75;
                buffer[i] = (short) (sample * Short.MAX_VALUE);
            }
            playPcmBuffer(buffer, sampleRate);
        }});
    }

    public void playGameOver() {
        if (!soundEnabled) return;
        audioExecutor.execute(new Runnable() {
            @Override
            public void run() {
            int sampleRate = 22050;
            int numSamples = (int) (0.50 * sampleRate);
            short[] buffer = new short[numSamples];
            for (int i = 0; i < numSamples; i++) {
                double t = (double) i / sampleRate;
                double freq = 340.0 * Math.exp(-t * 2.2);
                double env = Math.exp(-t * 3.5);
                double sample = Math.sin(2.0 * Math.PI * freq * t) * env * 0.65;
                buffer[i] = (short) (sample * Short.MAX_VALUE);
            }
            playPcmBuffer(buffer, sampleRate);
        }});
    }

    public void playButtonClick() {
        if (!soundEnabled) return;
        audioExecutor.execute(new Runnable() {
            @Override
            public void run() {
            int sampleRate = 22050;
            int numSamples = (int) (0.05 * sampleRate);
            short[] buffer = new short[numSamples];
            for (int i = 0; i < numSamples; i++) {
                double t = (double) i / sampleRate;
                double sample = Math.sin(2.0 * Math.PI * 750.0 * t) * (1.0 - t / 0.05) * 0.45;
                buffer[i] = (short) (sample * Short.MAX_VALUE);
            }
            playPcmBuffer(buffer, sampleRate);
        }});
    }

    public synchronized void startMusic() {
        if (!musicEnabled || isMusicPlaying) return;
        isMusicPlaying = true;
        musicThread = new Thread(new Runnable() {
            @Override
            public void run() {
            int sampleRate = 22050;
            int bufferSize = AudioTrack.getMinBufferSize(sampleRate,
                    AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
            if (bufferSize <= 0) bufferSize = 4096;

            final AudioTrack track = new AudioTrack(AudioManager.STREAM_MUSIC, sampleRate,
                    AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT,
                    bufferSize, AudioTrack.MODE_STREAM);

            track.play();
            musicTrack = track;

            double bpm = 128.0;
            double beatDuration = 60.0 / bpm;
            int samplesPerBeat = (int) (beatDuration * sampleRate);
            double[] bassNotes = {110.0, 110.0, 130.81, 146.83, 110.0, 110.0, 98.0, 123.47};

            short[] chunk = new short[512];
            long totalSamples = 0;

            while (isMusicPlaying) {
                for (int i = 0; i < chunk.length; i++) {
                    double t = (double) totalSamples / sampleRate;
                    int beatIndex = (int) ((totalSamples / samplesPerBeat) % bassNotes.length);
                    double beatProgress = ((double) (totalSamples % samplesPerBeat)) / samplesPerBeat;

                    double freq = bassNotes[beatIndex];
                    double synthEnv = Math.exp(-beatProgress * 4.0);
                    double bass = Math.sin(2.0 * Math.PI * freq * t) * synthEnv * 0.22;
                    double sub = Math.sin(Math.PI * freq * t) * synthEnv * 0.18;

                    // Hi-hat pulse on every 1/2 beat
                    double hiHatProgress = (beatProgress * 2.0) % 1.0;
                    double hiHat = (Math.random() * 2.0 - 1.0) * Math.exp(-hiHatProgress * 25.0) * 0.07;

                    double out = (bass + sub + hiHat) * 0.85;
                    chunk[i] = (short) (out * Short.MAX_VALUE);
                    totalSamples++;
                }
                track.write(chunk, 0, chunk.length);
            }

            try {
                track.stop();
                track.release();
            } catch (Exception ignored) {}
        }});
        musicThread.start();
    }

    public synchronized void stopMusic() {
        isMusicPlaying = false;
        if (musicThread != null) {
            musicThread.interrupt();
            musicThread = null;
        }
    }

    private void playPcmBuffer(final short[] buffer, final int sampleRate) {
        try {
            final AudioTrack track = new AudioTrack(AudioManager.STREAM_MUSIC, sampleRate,
                    AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT,
                    buffer.length * 2, AudioTrack.MODE_STATIC);
            track.write(buffer, 0, buffer.length);
            track.play();
            // Automatically release after playback
            new Thread(new Runnable() {
                @Override
                public void run() {
                try {
                    Thread.sleep((long) ((buffer.length * 1000.0) / sampleRate) + 50);
                    track.stop();
                    track.release();
                } catch (Exception ignored) {}
            }}).start();
        } catch (Exception ignored) {}
    }

    public void release() {
        stopMusic();
        if (audioExecutor != null) {
            audioExecutor.shutdown();
        }
    }
}
