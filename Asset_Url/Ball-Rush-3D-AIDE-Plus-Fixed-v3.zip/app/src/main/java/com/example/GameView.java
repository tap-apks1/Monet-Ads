package com.example;

import android.content.Context;
import android.opengl.GLSurfaceView;
import android.view.KeyEvent;
import android.view.MotionEvent;

/**
 * GLSurfaceView host for Ball Rush 3D game rendering and touch dispatch.
 */
public class GameView extends GLSurfaceView implements InputManager.InputListener {

    private GameManager gameManager;
    private GameRenderer renderer;
    private InputManager inputManager;

    public GameView(Context context, GameManager gameManager) {
        super(context);
        this.gameManager = gameManager;

        setEGLContextClientVersion(2);
        setPreserveEGLContextOnPause(true);

        renderer = new GameRenderer(gameManager);
        setRenderer(renderer);
        setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);

        inputManager = new InputManager(this);
        setOnTouchListener(inputManager);

        setFocusable(true);
        setFocusableInTouchMode(true);
        requestFocus();
    }

    @Override
    public void onSwipeLeft() {
        if (gameManager.getCurrentState() == GameManager.State.PLAYING) {
            gameManager.getPlayer().moveLeft();
        }
    }

    @Override
    public void onSwipeRight() {
        if (gameManager.getCurrentState() == GameManager.State.PLAYING) {
            gameManager.getPlayer().moveRight();
        }
    }

    @Override
    public void onSwipeUp() {
        if (gameManager.getCurrentState() == GameManager.State.PLAYING) {
            gameManager.getPlayer().jump();
        }
    }

    @Override
    public void onTap() {
        if (gameManager.getCurrentState() == GameManager.State.MENU) {
            gameManager.startGame();
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (inputManager != null && inputManager.handleKeyDown(keyCode, event)) {
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }
}
