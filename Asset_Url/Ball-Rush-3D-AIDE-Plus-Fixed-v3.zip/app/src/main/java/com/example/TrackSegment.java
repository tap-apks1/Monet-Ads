package com.example;

/**
 * 3D Track Segment piece. Supports straight platforms, gaps, ramps, and moving platforms.
 */
public class TrackSegment {

    public enum SegmentType {
        NORMAL,
        GAP,
        RAMP,
        MOVING_PLATFORM,
        SPEED_BOOSTER
    }

    public SegmentType type = SegmentType.NORMAL;
    public float zStart = 0.0f;
    public float length = 12.0f;
    public float width = 7.5f;
    public float height = 1.0f;
    public float yElevation = 0.0f;

    // Moving platform properties
    public float movingAmplitude = 2.0f;
    public float movingSpeed = 2.5f;
    public float movingOffsetX = 0.0f;
    public float time = 0.0f;

    // Active status
    public boolean active = true;

    public void init(SegmentType type, float zStart, float length, float yElevation) {
        this.type = type;
        this.zStart = zStart;
        this.length = length;
        this.yElevation = yElevation;
        this.width = 7.5f;
        this.height = 1.0f;
        this.movingOffsetX = 0.0f;
        this.time = (float) (Math.random() * Math.PI * 2.0);
        this.active = true;
    }

    public void update(float dt) {
        if (type == SegmentType.MOVING_PLATFORM) {
            time += dt * movingSpeed;
            movingOffsetX = (float) Math.sin(time) * movingAmplitude;
        }
    }

    public float getZCenter() {
        return zStart + length * 0.5f;
    }

    public float getZEnd() {
        return zStart + length;
    }

    public boolean containsZ(float z) {
        return z >= zStart && z <= (zStart + length);
    }
}
