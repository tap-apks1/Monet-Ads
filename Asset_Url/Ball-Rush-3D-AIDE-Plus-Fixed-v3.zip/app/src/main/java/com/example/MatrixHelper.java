package com.example;

import android.opengl.Matrix;

/**
 * 4x4 Matrix mathematical helper for OpenGL ES 2.0 transformations.
 * Compatible with pure Java Android SDK & AIDE Plus.
 */
public class MatrixHelper {

    public static void perspectiveM(float[] m, float yFovDeg, float aspect, float zNear, float zFar) {
        Matrix.perspectiveM(m, 0, yFovDeg, aspect, zNear, zFar);
    }

    public static void setLookAtM(float[] rm, float eyeX, float eyeY, float eyeZ,
                                 float centerX, float centerY, float centerZ,
                                 float upX, float upY, float upZ) {
        Matrix.setLookAtM(rm, 0, eyeX, eyeY, eyeZ, centerX, centerY, centerZ, upX, upY, upZ);
    }

    public static void setIdentityM(float[] sm) {
        Matrix.setIdentityM(sm, 0);
    }

    public static void translateM(float[] m, float x, float y, float z) {
        Matrix.translateM(m, 0, x, y, z);
    }

    public static void rotateM(float[] m, float a, float x, float y, float z) {
        Matrix.rotateM(m, 0, a, x, y, z);
    }

    public static void scaleM(float[] m, float x, float y, float z) {
        Matrix.scaleM(m, 0, x, y, z);
    }

    public static void multiplyMM(float[] result, float[] lhs, float[] rhs) {
        Matrix.multiplyMM(result, 0, lhs, 0, rhs, 0);
    }
}
