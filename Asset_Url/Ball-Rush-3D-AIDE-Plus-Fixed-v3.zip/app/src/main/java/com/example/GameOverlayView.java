package com.example;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * Clean, modern native UI overlay for Ball Rush 3D.
 * Manages Main Menu, In-game HUD, Pause Dialog, Game Over Dialog, Settings, and About screens.
 */
public class GameOverlayView extends FrameLayout implements GameManager.StateListener {

    private GameManager gameManager;

    // View Containers
    private LinearLayout menuLayout;
    private FrameLayout hudLayout;
    private LinearLayout pauseLayout;
    private LinearLayout gameOverLayout;

    // HUD Elements
    private TextView tvScore;
    private TextView tvBest;
    private TextView tvCoins;
    private View btnLeft;
    private View btnRight;
    private View btnJump;
    private LinearLayout bottomControlsContainer;

    // Game Over Elements
    private TextView tvGameOverScore;
    private TextView tvGameOverBest;
    private TextView tvGameOverCoins;
    private TextView tvNewBestBanner;

    public GameOverlayView(Context context, GameManager gameManager) {
        super(context);
        this.gameManager = gameManager;
        gameManager.setStateListener(this);

        initViews(context);
        showMenu();
    }

    private void initViews(final Context context) {
        setBackgroundColor(Color.TRANSPARENT);

        buildMainMenu(context);
        buildHud(context);
        buildPauseMenu(context);
        buildGameOverMenu(context);

        addView(menuLayout);
        addView(hudLayout);
        addView(pauseLayout);
        addView(gameOverLayout);
    }

    private void buildMainMenu(final Context context) {
        menuLayout = new LinearLayout(context);
        menuLayout.setOrientation(LinearLayout.VERTICAL);
        menuLayout.setGravity(Gravity.CENTER_HORIZONTAL);
        menuLayout.setPadding(dp(24), dp(48), dp(24), dp(32));
        menuLayout.setLayoutParams(new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // Title Box
        LinearLayout titleBox = new LinearLayout(context);
        titleBox.setOrientation(LinearLayout.VERTICAL);
        titleBox.setGravity(Gravity.CENTER);
        titleBox.setPadding(dp(16), dp(16), dp(16), dp(16));

        TextView tvTitle1 = new TextView(context);
        tvTitle1.setText("BALL RUSH");
        tvTitle1.setTextSize(36);
        tvTitle1.setTypeface(Typeface.DEFAULT_BOLD);
        tvTitle1.setTextColor(Color.WHITE);
        tvTitle1.setShadowLayer(16.0f, 0, 0, Color.parseColor("#00E5FF"));
        titleBox.addView(tvTitle1);

        TextView tvTitle2 = new TextView(context);
        tvTitle2.setText("3D");
        tvTitle2.setTextSize(42);
        tvTitle2.setTypeface(Typeface.DEFAULT_BOLD);
        tvTitle2.setTextColor(Color.parseColor("#00E5FF"));
        tvTitle2.setShadowLayer(20.0f, 0, 0, Color.parseColor("#00B0FF"));
        titleBox.addView(tvTitle2);

        TextView tvSubtitle = new TextView(context);
        tvSubtitle.setText("JUMP • DODGE • SURVIVE");
        tvSubtitle.setTextSize(13);
        tvSubtitle.setLetterSpacing(0.2f);
        tvSubtitle.setTextColor(Color.parseColor("#A0C0E0"));
        tvSubtitle.setPadding(0, dp(4), 0, 0);
        titleBox.addView(tvSubtitle);

        menuLayout.addView(titleBox);

        // Spacer
        View spacer = new View(context);
        LinearLayout.LayoutParams spParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1.0f);
        spacer.setLayoutParams(spParams);
        menuLayout.addView(spacer);

        // Buttons Box
        LinearLayout btnBox = new LinearLayout(context);
        btnBox.setOrientation(LinearLayout.VERTICAL);
        btnBox.setGravity(Gravity.CENTER_HORIZONTAL);
        btnBox.setLayoutParams(new LinearLayout.LayoutParams(dp(260), ViewGroup.LayoutParams.WRAP_CONTENT));

        // PLAY Button
        TextView btnPlay = createStyledButton(context, "▶  PLAY", Color.parseColor("#00E676"), Color.parseColor("#00B0FF"));
        btnPlay.setTextSize(20);
        btnPlay.setPadding(dp(24), dp(16), dp(24), dp(16));
        btnPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            SoundManager.getInstance().playButtonClick();
            gameManager.startGame();
        }});
        btnBox.addView(btnPlay);

        // Pulse Animation on Play Button
        ObjectAnimator scaleX = ObjectAnimator.ofFloat(btnPlay, "scaleX", 1.0f, 1.06f, 1.0f);
        scaleX.setDuration(1200);
        scaleX.setRepeatCount(ValueAnimator.INFINITE);
        scaleX.setInterpolator(new AccelerateDecelerateInterpolator());
        scaleX.start();

        ObjectAnimator scaleY = ObjectAnimator.ofFloat(btnPlay, "scaleY", 1.0f, 1.06f, 1.0f);
        scaleY.setDuration(1200);
        scaleY.setRepeatCount(ValueAnimator.INFINITE);
        scaleY.setInterpolator(new AccelerateDecelerateInterpolator());
        scaleY.start();

        // BEST SCORE Badge Button
        TextView btnBest = createOutlineButton(context, "🏆  BEST SCORE: " + gameManager.getScoreManager().getBestScore());
        btnBest.setPadding(dp(16), dp(12), dp(16), dp(12));
        btnBest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            SoundManager.getInstance().playButtonClick();
            showBestScoreDialog(context);
        }});
        LinearLayout.LayoutParams bParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        bParams.setMargins(0, dp(12), 0, 0);
        btnBest.setLayoutParams(bParams);
        btnBox.addView(btnBest);

        // SETTINGS Button
        TextView btnSettings = createOutlineButton(context, "⚙  SETTINGS");
        btnSettings.setPadding(dp(16), dp(12), dp(16), dp(12));
        btnSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            SoundManager.getInstance().playButtonClick();
            showSettingsDialog(context);
        }});
        btnSettings.setLayoutParams(bParams);
        btnBox.addView(btnSettings);

        // ABOUT Button
        TextView btnAbout = createOutlineButton(context, "ℹ  ABOUT & AIDE+");
        btnAbout.setPadding(dp(16), dp(12), dp(16), dp(12));
        btnAbout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            SoundManager.getInstance().playButtonClick();
            showAboutDialog(context);
        }});
        btnAbout.setLayoutParams(bParams);
        btnBox.addView(btnAbout);

        menuLayout.addView(btnBox);

        // Footer
        TextView tvFooter = new TextView(context);
        tvFooter.setText("SMALL BALL • BIG ADVENTURE");
        tvFooter.setTextSize(11);
        tvFooter.setLetterSpacing(0.15f);
        tvFooter.setTextColor(Color.parseColor("#6080A0"));
        tvFooter.setPadding(0, dp(24), 0, 0);
        menuLayout.addView(tvFooter);
    }

    private void buildHud(final Context context) {
        hudLayout = new FrameLayout(context);
        hudLayout.setLayoutParams(new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        hudLayout.setVisibility(View.GONE);

        // Top HUD Header Bar
        LinearLayout topBar = new LinearLayout(context);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setPadding(dp(16), dp(36), dp(16), dp(12));

        GradientDrawable topBg = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{Color.parseColor("#D0000000"), Color.TRANSPARENT});
        topBar.setBackground(topBg);

        LayoutParams topParams = new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        topParams.gravity = Gravity.TOP;
        topBar.setLayoutParams(topParams);

        // Pause Button
        TextView btnPause = new TextView(context);
        btnPause.setText("⏸");
        btnPause.setTextSize(22);
        btnPause.setTextColor(Color.WHITE);
        btnPause.setGravity(Gravity.CENTER);
        btnPause.setPadding(dp(12), dp(8), dp(12), dp(8));
        GradientDrawable pBg = new GradientDrawable();
        pBg.setColor(Color.parseColor("#44102030"));
        pBg.setCornerRadius(dp(12));
        pBg.setStroke(dp(1), Color.parseColor("#4400E5FF"));
        btnPause.setBackground(pBg);
        btnPause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            SoundManager.getInstance().playButtonClick();
            gameManager.pauseGame();
        }});
        topBar.addView(btnPause);

        // Score display
        LinearLayout scoreBox = new LinearLayout(context);
        scoreBox.setOrientation(LinearLayout.VERTICAL);
        scoreBox.setPadding(dp(16), 0, 0, 0);
        LinearLayout.LayoutParams scParams = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        scoreBox.setLayoutParams(scParams);

        TextView lblScore = new TextView(context);
        lblScore.setText("SCORE");
        lblScore.setTextSize(10);
        lblScore.setLetterSpacing(0.1f);
        lblScore.setTextColor(Color.parseColor("#80B0D0"));
        scoreBox.addView(lblScore);

        tvScore = new TextView(context);
        tvScore.setText("0");
        tvScore.setTextSize(24);
        tvScore.setTypeface(Typeface.DEFAULT_BOLD);
        tvScore.setTextColor(Color.WHITE);
        scoreBox.addView(tvScore);
        topBar.addView(scoreBox);

        // Coins display
        LinearLayout coinBox = new LinearLayout(context);
        coinBox.setOrientation(LinearLayout.HORIZONTAL);
        coinBox.setGravity(Gravity.CENTER_VERTICAL);
        coinBox.setPadding(dp(12), dp(6), dp(12), dp(6));
        GradientDrawable cBg = new GradientDrawable();
        cBg.setColor(Color.parseColor("#33FFD700"));
        cBg.setCornerRadius(dp(16));
        cBg.setStroke(dp(1), Color.parseColor("#88FFD700"));
        coinBox.setBackground(cBg);

        TextView coinIcon = new TextView(context);
        coinIcon.setText("🪙 ");
        coinIcon.setTextSize(14);
        coinBox.addView(coinIcon);

        tvCoins = new TextView(context);
        tvCoins.setText("0");
        tvCoins.setTextSize(16);
        tvCoins.setTypeface(Typeface.DEFAULT_BOLD);
        tvCoins.setTextColor(Color.parseColor("#FFD700"));
        coinBox.addView(tvCoins);
        topBar.addView(coinBox);

        // Best score display
        LinearLayout bestBox = new LinearLayout(context);
        bestBox.setOrientation(LinearLayout.VERTICAL);
        bestBox.setGravity(Gravity.END);
        bestBox.setPadding(dp(16), 0, dp(4), 0);

        TextView lblBest = new TextView(context);
        lblBest.setText("BEST");
        lblBest.setTextSize(10);
        lblBest.setLetterSpacing(0.1f);
        lblBest.setTextColor(Color.parseColor("#80B0D0"));
        bestBox.addView(lblBest);

        tvBest = new TextView(context);
        tvBest.setText("" + gameManager.getScoreManager().getBestScore());
        tvBest.setTextSize(18);
        tvBest.setTypeface(Typeface.DEFAULT_BOLD);
        tvBest.setTextColor(Color.parseColor("#00E5FF"));
        bestBox.addView(tvBest);
        topBar.addView(bestBox);

        hudLayout.addView(topBar);

        // Bottom Controls Container (Touch helpers + swipe guide)
        bottomControlsContainer = new LinearLayout(context);
        bottomControlsContainer.setOrientation(LinearLayout.VERTICAL);
        bottomControlsContainer.setGravity(Gravity.CENTER_HORIZONTAL);
        bottomControlsContainer.setPadding(dp(16), dp(12), dp(16), dp(28));

        LayoutParams botParams = new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        botParams.gravity = Gravity.BOTTOM;
        bottomControlsContainer.setLayoutParams(botParams);

        // On-Screen Arrow Buttons Row
        LinearLayout buttonRow = new LinearLayout(context);
        buttonRow.setOrientation(LinearLayout.HORIZONTAL);
        buttonRow.setGravity(Gravity.CENTER);
        buttonRow.setPadding(0, 0, 0, dp(8));

        btnLeft = createTouchControlButton(context, "◀  LEFT", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gameManager.getPlayer().moveLeft();
            }
        });
        btnJump = createTouchControlButton(context, "▲  JUMP", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gameManager.getPlayer().jump();
            }
        });
        btnRight = createTouchControlButton(context, "RIGHT  ▶", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gameManager.getPlayer().moveRight();
            }
        });

        buttonRow.addView(btnLeft);
        View rowSpace1 = new View(context);
        rowSpace1.setLayoutParams(new LinearLayout.LayoutParams(dp(12), 1));
        buttonRow.addView(rowSpace1);

        buttonRow.addView(btnJump);
        View rowSpace2 = new View(context);
        rowSpace2.setLayoutParams(new LinearLayout.LayoutParams(dp(12), 1));
        buttonRow.addView(rowSpace2);

        buttonRow.addView(btnRight);

        bottomControlsContainer.addView(buttonRow);

        // Swipe hint indicator
        TextView tvSwipeHint = new TextView(context);
        tvSwipeHint.setText("SWIPE LEFT / RIGHT TO MOVE • SWIPE UP TO JUMP");
        tvSwipeHint.setTextSize(10);
        tvSwipeHint.setLetterSpacing(0.08f);
        tvSwipeHint.setTextColor(Color.parseColor("#80A0C0"));
        tvSwipeHint.setShadowLayer(4.0f, 0, 0, Color.BLACK);
        bottomControlsContainer.addView(tvSwipeHint);

        hudLayout.addView(bottomControlsContainer);
    }

    private void buildPauseMenu(final Context context) {
        pauseLayout = new LinearLayout(context);
        pauseLayout.setOrientation(LinearLayout.VERTICAL);
        pauseLayout.setGravity(Gravity.CENTER);
        pauseLayout.setBackgroundColor(Color.parseColor("#E0050B14"));
        pauseLayout.setPadding(dp(24), dp(24), dp(24), dp(24));
        pauseLayout.setLayoutParams(new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        pauseLayout.setVisibility(View.GONE);

        TextView tvPaused = new TextView(context);
        tvPaused.setText("PAUSED");
        tvPaused.setTextSize(32);
        tvPaused.setTypeface(Typeface.DEFAULT_BOLD);
        tvPaused.setTextColor(Color.WHITE);
        tvPaused.setShadowLayer(16.0f, 0, 0, Color.parseColor("#00E5FF"));
        pauseLayout.addView(tvPaused);

        // Buttons
        LinearLayout btnBox = new LinearLayout(context);
        btnBox.setOrientation(LinearLayout.VERTICAL);
        btnBox.setLayoutParams(new LinearLayout.LayoutParams(dp(240), ViewGroup.LayoutParams.WRAP_CONTENT));
        btnBox.setPadding(0, dp(32), 0, 0);

        TextView btnResume = createStyledButton(context, "RESUME", Color.parseColor("#00E676"), Color.parseColor("#00B0FF"));
        btnResume.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            SoundManager.getInstance().playButtonClick();
            gameManager.resumeGame();
        }});
        btnBox.addView(btnResume);

        TextView btnRestart = createOutlineButton(context, "RESTART");
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(12), 0, 0);
        btnRestart.setLayoutParams(lp);
        btnRestart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            SoundManager.getInstance().playButtonClick();
            gameManager.restartGame();
        }});
        btnBox.addView(btnRestart);

        TextView btnMenu = createOutlineButton(context, "MAIN MENU");
        btnMenu.setLayoutParams(lp);
        btnMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            SoundManager.getInstance().playButtonClick();
            gameManager.goToMenu();
        }});
        btnBox.addView(btnMenu);

        pauseLayout.addView(btnBox);
    }

    private void buildGameOverMenu(final Context context) {
        gameOverLayout = new LinearLayout(context);
        gameOverLayout.setOrientation(LinearLayout.VERTICAL);
        gameOverLayout.setGravity(Gravity.CENTER);
        gameOverLayout.setBackgroundColor(Color.parseColor("#E6050B14"));
        gameOverLayout.setPadding(dp(24), dp(24), dp(24), dp(24));
        gameOverLayout.setLayoutParams(new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        gameOverLayout.setVisibility(View.GONE);

        // Title
        TextView tvGo = new TextView(context);
        tvGo.setText("GAME OVER");
        tvGo.setTextSize(36);
        tvGo.setTypeface(Typeface.DEFAULT_BOLD);
        tvGo.setTextColor(Color.parseColor("#FF2A55"));
        tvGo.setShadowLayer(20.0f, 0, 0, Color.parseColor("#FF0033"));
        gameOverLayout.addView(tvGo);

        // New Best Banner
        tvNewBestBanner = new TextView(context);
        tvNewBestBanner.setText("★ NEW BEST RECORD! ★");
        tvNewBestBanner.setTextSize(16);
        tvNewBestBanner.setTypeface(Typeface.DEFAULT_BOLD);
        tvNewBestBanner.setTextColor(Color.parseColor("#FFD700"));
        tvNewBestBanner.setShadowLayer(12.0f, 0, 0, Color.parseColor("#FF8800"));
        tvNewBestBanner.setPadding(0, dp(8), 0, dp(8));
        tvNewBestBanner.setVisibility(View.GONE);
        gameOverLayout.addView(tvNewBestBanner);

        // Stats Card
        LinearLayout statsCard = new LinearLayout(context);
        statsCard.setOrientation(LinearLayout.VERTICAL);
        statsCard.setLayoutParams(new LinearLayout.LayoutParams(dp(280), ViewGroup.LayoutParams.WRAP_CONTENT));
        statsCard.setPadding(dp(24), dp(20), dp(24), dp(20));
        GradientDrawable cardBg = new GradientDrawable();
        cardBg.setColor(Color.parseColor("#22102030"));
        cardBg.setCornerRadius(dp(16));
        cardBg.setStroke(dp(1), Color.parseColor("#4400E5FF"));
        statsCard.setBackground(cardBg);

        LinearLayout.LayoutParams scMargin = new LinearLayout.LayoutParams(dp(280), ViewGroup.LayoutParams.WRAP_CONTENT);
        scMargin.setMargins(0, dp(16), 0, dp(24));
        statsCard.setLayoutParams(scMargin);

        tvGameOverScore = createStatRow(context, statsCard, "FINAL SCORE", "0", Color.WHITE);
        tvGameOverBest = createStatRow(context, statsCard, "BEST SCORE", "0", Color.parseColor("#00E5FF"));
        tvGameOverCoins = createStatRow(context, statsCard, "COINS COLLECTED", "0", Color.parseColor("#FFD700"));

        gameOverLayout.addView(statsCard);

        // Buttons
        LinearLayout btnBox = new LinearLayout(context);
        btnBox.setOrientation(LinearLayout.VERTICAL);
        btnBox.setLayoutParams(new LinearLayout.LayoutParams(dp(260), ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView btnPlayAgain = createStyledButton(context, "PLAY AGAIN", Color.parseColor("#00E676"), Color.parseColor("#00B0FF"));
        btnPlayAgain.setTextSize(18);
        btnPlayAgain.setPadding(dp(20), dp(14), dp(20), dp(14));
        btnPlayAgain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            SoundManager.getInstance().playButtonClick();
            gameManager.startGame();
        }});
        btnBox.addView(btnPlayAgain);

        TextView btnMenu = createOutlineButton(context, "MAIN MENU");
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(12), 0, 0);
        btnMenu.setLayoutParams(lp);
        btnMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            SoundManager.getInstance().playButtonClick();
            gameManager.goToMenu();
        }});
        btnBox.addView(btnMenu);

        gameOverLayout.addView(btnBox);
    }

    private TextView createStatRow(Context context, LinearLayout parent, String label, String value, int valueColor) {
        LinearLayout row = new LinearLayout(context);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(4), 0, dp(4));

        TextView tvLabel = new TextView(context);
        tvLabel.setText(label);
        tvLabel.setTextSize(12);
        tvLabel.setTextColor(Color.parseColor("#90B0D0"));
        tvLabel.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f));
        row.addView(tvLabel);

        TextView tvVal = new TextView(context);
        tvVal.setText(value);
        tvVal.setTextSize(16);
        tvVal.setTypeface(Typeface.DEFAULT_BOLD);
        tvVal.setTextColor(valueColor);
        row.addView(tvVal);

        parent.addView(row);
        return tvVal;
    }

    private TextView createStyledButton(Context context, String text, int startColor, int endColor) {
        TextView btn = new TextView(context);
        btn.setText(text);
        btn.setTextSize(16);
        btn.setTypeface(Typeface.DEFAULT_BOLD);
        btn.setTextColor(Color.BLACK);
        btn.setGravity(Gravity.CENTER);
        btn.setPadding(dp(16), dp(14), dp(16), dp(14));

        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{startColor, endColor});
        bg.setCornerRadius(dp(28));
        btn.setBackground(bg);
        return btn;
    }

    private TextView createOutlineButton(Context context, String text) {
        TextView btn = new TextView(context);
        btn.setText(text);
        btn.setTextSize(14);
        btn.setTypeface(Typeface.DEFAULT_BOLD);
        btn.setTextColor(Color.WHITE);
        btn.setGravity(Gravity.CENTER);
        btn.setPadding(dp(16), dp(12), dp(16), dp(12));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#33102030"));
        bg.setCornerRadius(dp(24));
        bg.setStroke(dp(1), Color.parseColor("#6600E5FF"));
        btn.setBackground(bg);
        return btn;
    }

    private View createTouchControlButton(Context context, String label, OnClickListener listener) {
        TextView btn = new TextView(context);
        btn.setText(label);
        btn.setTextSize(12);
        btn.setTypeface(Typeface.DEFAULT_BOLD);
        btn.setTextColor(Color.WHITE);
        btn.setGravity(Gravity.CENTER);
        btn.setPadding(dp(16), dp(12), dp(16), dp(12));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#77102030"));
        bg.setCornerRadius(dp(16));
        bg.setStroke(dp(1), Color.parseColor("#8800E5FF"));
        btn.setBackground(bg);
        btn.setOnClickListener(listener);
        return btn;
    }

    private void showBestScoreDialog(final Context context) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("🏆 BEST SCORE & STATS");
        builder.setMessage("High Score: " + gameManager.getScoreManager().getBestScore() + " pts\n" +
                "Total Coins: " + gameManager.getScoreManager().getTotalCoins() + " 🪙\n\n" +
                "Survive longer and jump gaps to beat your personal best!");
        builder.setPositiveButton("AWESOME", null);
        builder.show();
    }

    private void showSettingsDialog(final Context context) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("⚙ SETTINGS");

        String[] options = {
                "Sound FX: " + (SoundManager.getInstance().isSoundEnabled() ? "ON" : "OFF"),
                "Music Beat: " + (SoundManager.getInstance().isMusicEnabled() ? "ON" : "OFF"),
                "On-Screen Buttons: " + (gameManager.isShowTouchControls() ? "SHOW" : "HIDE"),
                "Environment: " + gameManager.getCurrentEnvironment().name
        };

        builder.setItems(options, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            switch (which) {
                case 0:
                    SoundManager.getInstance().setSoundEnabled(!SoundManager.getInstance().isSoundEnabled());
                    showSettingsDialog(context);
                    break;
                case 1:
                    SoundManager.getInstance().setMusicEnabled(!SoundManager.getInstance().isMusicEnabled());
                    showSettingsDialog(context);
                    break;
                case 2:
                    gameManager.setShowTouchControls(!gameManager.isShowTouchControls());
                    bottomControlsContainer.setVisibility(gameManager.isShowTouchControls() ? View.VISIBLE : View.GONE);
                    showSettingsDialog(context);
                    break;
                case 3:
                    showEnvironmentSelector(context);
                    break;
            }
        }});
        builder.setPositiveButton("CLOSE", null);
        builder.show();
    }

    private void showEnvironmentSelector(final Context context) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("SELECT 3D ENVIRONMENT");
        String[] envs = {"Sky City (Default)", "Desert Ruins", "Neon Night", "Lava World"};
        builder.setItems(envs, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            switch (which) {
                case 0: gameManager.setEnvironment(EnvironmentConfig.Theme.SKY_CITY); break;
                case 1: gameManager.setEnvironment(EnvironmentConfig.Theme.DESERT_RUINS); break;
                case 2: gameManager.setEnvironment(EnvironmentConfig.Theme.NEON_NIGHT); break;
                case 3: gameManager.setEnvironment(EnvironmentConfig.Theme.LAVA_WORLD); break;
            }
        }});
        builder.setNegativeButton("CANCEL", null);
        builder.show();
    }

    private void showAboutDialog(final Context context) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("BALL RUSH 3D • ABOUT");
        builder.setMessage("🎮 BALL RUSH 3D\n" +
                "Engine: Pure Java & OpenGL ES 2.0 Native\n" +
                "Compatibility: AIDE Plus, Android Studio, Native SDK\n\n" +
                "🕹 CONTROLS:\n" +
                "• Swipe Left / Right: Switch Lanes\n" +
                "• Swipe Up: Jump over Blocks & Gaps\n" +
                "• Touch Buttons: Optional on-screen controls\n" +
                "• Keyboard: Arrow keys or A/D/Space\n\n" +
                "✨ FEATURES:\n" +
                "• 3D Glossy Ball with Glowing Neon Rings\n" +
                "• Procedural infinite tracks with gaps & moving platforms\n" +
                "• 6 Obstacle variations: Blocks, Spikes, Hammers, Lasers\n" +
                "• 3D Golden Coins with particle effects\n" +
                "• Dynamic 3D lighting, fog, and ball shadow\n" +
                "• 4 Unique Environments (Sky City, Desert, Neon, Lava)\n" +
                "• Procedural retro synth arcade audio engine");
        builder.setPositiveButton("GOT IT", null);
        builder.show();
    }

    private int dp(int dpVal) {
        return (int) (dpVal * getResources().getDisplayMetrics().density);
    }

    @Override
    public void onStateChanged(GameManager.State newState) {
        menuLayout.setVisibility(newState == GameManager.State.MENU ? View.VISIBLE : View.GONE);
        hudLayout.setVisibility(newState == GameManager.State.PLAYING ? View.VISIBLE : View.GONE);
        pauseLayout.setVisibility(newState == GameManager.State.PAUSED ? View.VISIBLE : View.GONE);
        gameOverLayout.setVisibility(newState == GameManager.State.GAME_OVER ? View.VISIBLE : View.GONE);
    }

    @Override
    public void onScoreUpdated(int score, int best, int coins) {
        if (tvScore != null) tvScore.setText("" + score);
        if (tvBest != null) tvBest.setText("" + best);
        if (tvCoins != null) tvCoins.setText("" + coins);
    }

    @Override
    public void onGameOver(int score, int best, int coins, boolean isNewBest) {
        if (tvGameOverScore != null) tvGameOverScore.setText("" + score);
        if (tvGameOverBest != null) tvGameOverBest.setText("" + best);
        if (tvGameOverCoins != null) tvGameOverCoins.setText("+" + coins);
        if (tvNewBestBanner != null) {
            tvNewBestBanner.setVisibility(isNewBest ? View.VISIBLE : View.GONE);
        }
    }

    public void showMenu() {
        onStateChanged(GameManager.State.MENU);
    }
}
