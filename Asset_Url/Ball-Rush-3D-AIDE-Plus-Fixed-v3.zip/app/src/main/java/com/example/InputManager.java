package com.example;

import android.view.GestureDetector;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;

/**
 * Handles Touch gestures (Swipe Left, Swipe Right, Swipe Up to Jump),
 * on-screen button controls, and keyboard inputs for Ball Rush 3D.
 */
public class InputManager implements View.OnTouchListener {

    public interface InputListener {
        void onSwipeLeft();
        void onSwipeRight();
        void onSwipeUp();
        void onTap();
    }

    private InputListener listener;
    private float startX;
    private float startY;
    private long startTime;
    private static final float SWIPE_THRESHOLD = 50.0f; // px
    private static final long MAX_SWIPE_TIME_MS = 450;

    public InputManager(InputListener listener) {
        this.listener = listener;
    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        if (listener == null) return false;

        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                startX = event.getX();
                startY = event.getY();
                startTime = System.currentTimeMillis();
                return true;

            case MotionEvent.ACTION_UP:
                float endX = event.getX();
                float endY = event.getY();
                long duration = System.currentTimeMillis() - startTime;

                float dx = endX - startX;
                float dy = endY - startY;

                if (duration <= MAX_SWIPE_TIME_MS) {
                    if (Math.abs(dx) > SWIPE_THRESHOLD && Math.abs(dx) > Math.abs(dy)) {
                        if (dx > 0) {
                            listener.onSwipeRight();
                        } else {
                            listener.onSwipeLeft();
                        }
                        return true;
                    } else if (Math.abs(dy) > SWIPE_THRESHOLD && Math.abs(dy) > Math.abs(dx)) {
                        if (dy < 0) {
                            listener.onSwipeUp();
                            return true;
                        }
                    } else if (Math.abs(dx) < 20.0f && Math.abs(dy) < 20.0f) {
                        listener.onTap();
                        return true;
                    }
                }
                return true;
        }
        return false;
    }

    public boolean handleKeyDown(int keyCode, KeyEvent event) {
        if (listener == null) return false;

        switch (keyCode) {
            case KeyEvent.KEYCODE_DPAD_LEFT:
            case KeyEvent.KEYCODE_A:
                listener.onSwipeLeft();
                return true;

            case KeyEvent.KEYCODE_DPAD_RIGHT:
            case KeyEvent.KEYCODE_D:
                listener.onSwipeRight();
                return true;

            case KeyEvent.KEYCODE_DPAD_UP:
            case KeyEvent.KEYCODE_SPACE:
            case KeyEvent.KEYCODE_W:
                listener.onSwipeUp();
                return true;
        }
        return false;
    }
}
