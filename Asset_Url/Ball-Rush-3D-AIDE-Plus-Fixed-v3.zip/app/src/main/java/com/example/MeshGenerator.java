package com.example;

import java.util.ArrayList;

/**
 * Generates procedural 3D meshes without requiring external 3D model files.
 * Optimizes vertices and normals for high performance on Android mobile GPUs.
 */
public class MeshGenerator {

    /**
     * Creates a 3D UV Sphere.
     */
    public static Mesh createSphere(float radius, int rings, int sectors) {
        float R = 1.0f / (float)(rings - 1);
        float S = 1.0f / (float)(sectors - 1);

        int numVertices = rings * sectors;
        float[] vertices = new float[numVertices * 3];
        float[] normals = new float[numVertices * 3];

        int vIndex = 0;
        for (int r = 0; r < rings; r++) {
            float v = r * R;
            float phi = (float) (Math.PI * v);
            float y = (float) Math.cos(phi);
            float sinPhi = (float) Math.sin(phi);

            for (int s = 0; s < sectors; s++) {
                float u = s * S;
                float theta = (float) (2.0 * Math.PI * u);
                float x = (float) (Math.cos(theta) * sinPhi);
                float z = (float) (Math.sin(theta) * sinPhi);

                vertices[vIndex] = x * radius;
                vertices[vIndex + 1] = y * radius;
                vertices[vIndex + 2] = z * radius;

                normals[vIndex] = x;
                normals[vIndex + 1] = y;
                normals[vIndex + 2] = z;

                vIndex += 3;
            }
        }

        int numIndices = (rings - 1) * (sectors - 1) * 6;
        short[] indices = new short[numIndices];
        int iIndex = 0;
        for (int r = 0; r < rings - 1; r++) {
            for (int s = 0; s < sectors - 1; s++) {
                short cur = (short) (r * sectors + s);
                short next = (short) (r * sectors + (s + 1));
                short curBelow = (short) ((r + 1) * sectors + s);
                short nextBelow = (short) ((r + 1) * sectors + (s + 1));

                indices[iIndex++] = cur;
                indices[iIndex++] = curBelow;
                indices[iIndex++] = next;

                indices[iIndex++] = next;
                indices[iIndex++] = curBelow;
                indices[iIndex++] = nextBelow;
            }
        }

        return new Mesh(vertices, normals, indices);
    }

    /**
     * Creates a 3D Cube / Box.
     */
    public static Mesh createCube(float width, float height, float depth) {
        float w = width * 0.5f;
        float h = height * 0.5f;
        float d = depth * 0.5f;

        float[] vertices = {
                // Front face
                -w, -h,  d,   w, -h,  d,   w,  h,  d,  -w,  h,  d,
                // Back face
                -w, -h, -d,  -w,  h, -d,   w,  h, -d,   w, -h, -d,
                // Top face
                -w,  h, -d,  -w,  h,  d,   w,  h,  d,   w,  h, -d,
                // Bottom face
                -w, -h, -d,   w, -h, -d,   w, -h,  d,  -w, -h,  d,
                // Right face
                 w, -h, -d,   w,  h, -d,   w,  h,  d,   w, -h,  d,
                // Left face
                -w, -h, -d,  -w, -h,  d,  -w,  h,  d,  -w,  h, -d
        };

        float[] normals = {
                // Front
                 0,  0,  1,   0,  0,  1,   0,  0,  1,   0,  0,  1,
                // Back
                 0,  0, -1,   0,  0, -1,   0,  0, -1,   0,  0, -1,
                // Top
                 0,  1,  0,   0,  1,  0,   0,  1,  0,   0,  1,  0,
                // Bottom
                 0, -1,  0,   0, -1,  0,   0, -1,  0,   0, -1,  0,
                // Right
                 1,  0,  0,   1,  0,  0,   1,  0,  0,   1,  0,  0,
                // Left
                -1,  0,  0,  -1,  0,  0,  -1,  0,  0,  -1,  0,  0
        };

        short[] indices = {
                 0,  1,  2,   0,  2,  3,    // Front
                 4,  5,  6,   4,  6,  7,    // Back
                 8,  9, 10,   8, 10, 11,    // Top
                12, 13, 14,  12, 14, 15,    // Bottom
                16, 17, 18,  16, 18, 19,    // Right
                20, 21, 22,  20, 22, 23     // Left
        };

        return new Mesh(vertices, normals, indices);
    }

    /**
     * Creates a 3D Cylinder / Coin geometry.
     */
    public static Mesh createCylinder(float radius, float height, int slices) {
        int numVertices = (slices + 1) * 4 + 2;
        float hHalf = height * 0.5f;

        ArrayList<Float> vList = new ArrayList<>();
        ArrayList<Float> nList = new ArrayList<>();
        ArrayList<Short> iList = new ArrayList<>();

        // Side vertices
        for (int i = 0; i <= slices; i++) {
            float angle = (float) (i * 2.0 * Math.PI / slices);
            float x = (float) Math.cos(angle);
            float z = (float) Math.sin(angle);

            // Bottom vertex
            vList.add(x * radius); vList.add(-hHalf); vList.add(z * radius);
            nList.add(x); nList.add(0.0f); nList.add(z);

            // Top vertex
            vList.add(x * radius); vList.add(hHalf); vList.add(z * radius);
            nList.add(x); nList.add(0.0f); nList.add(z);
        }

        for (short i = 0; i < slices; i++) {
            short b1 = (short) (i * 2);
            short t1 = (short) (i * 2 + 1);
            short b2 = (short) ((i + 1) * 2);
            short t2 = (short) ((i + 1) * 2 + 1);

            iList.add(b1); iList.add(t1); iList.add(b2);
            iList.add(b2); iList.add(t1); iList.add(t2);
        }

        // Top Cap center
        short topCenterIdx = (short) (vList.size() / 3);
        vList.add(0.0f); vList.add(hHalf); vList.add(0.0f);
        nList.add(0.0f); nList.add(1.0f); nList.add(0.0f);

        // Top cap vertices
        short topStartIdx = (short) (vList.size() / 3);
        for (int i = 0; i <= slices; i++) {
            float angle = (float) (i * 2.0 * Math.PI / slices);
            vList.add((float) Math.cos(angle) * radius);
            vList.add(hHalf);
            vList.add((float) Math.sin(angle) * radius);
            nList.add(0.0f); nList.add(1.0f); nList.add(0.0f);
        }
        for (short i = 0; i < slices; i++) {
            iList.add(topCenterIdx);
            iList.add((short) (topStartIdx + i));
            iList.add((short) (topStartIdx + i + 1));
        }

        // Bottom Cap center
        short bottomCenterIdx = (short) (vList.size() / 3);
        vList.add(0.0f); vList.add(-hHalf); vList.add(0.0f);
        nList.add(0.0f); nList.add(-1.0f); nList.add(0.0f);

        // Bottom cap vertices
        short botStartIdx = (short) (vList.size() / 3);
        for (int i = 0; i <= slices; i++) {
            float angle = (float) (i * 2.0 * Math.PI / slices);
            vList.add((float) Math.cos(angle) * radius);
            vList.add(-hHalf);
            vList.add((float) Math.sin(angle) * radius);
            nList.add(0.0f); nList.add(-1.0f); nList.add(0.0f);
        }
        for (short i = 0; i < slices; i++) {
            iList.add(bottomCenterIdx);
            iList.add((short) (botStartIdx + i + 1));
            iList.add((short) (botStartIdx + i));
        }

        float[] vArr = new float[vList.size()];
        for (int i = 0; i < vList.size(); i++) vArr[i] = vList.get(i);

        float[] nArr = new float[nList.size()];
        for (int i = 0; i < nList.size(); i++) nArr[i] = nList.get(i);

        short[] iArr = new short[iList.size()];
        for (int i = 0; i < iList.size(); i++) iArr[i] = iList.get(i);

        return new Mesh(vArr, nArr, iArr);
    }

    /**
     * Creates a Torus / Glowing Ring mesh for the Ball and portals.
     */
    public static Mesh createTorusRing(float rOuter, float rTube, int rings, int sides) {
        int numVertices = (rings + 1) * (sides + 1);
        float[] vertices = new float[numVertices * 3];
        float[] normals = new float[numVertices * 3];

        int vIndex = 0;
        for (int r = 0; r <= rings; r++) {
            float u = (float) (r * 2.0 * Math.PI / rings);
            float cu = (float) Math.cos(u);
            float su = (float) Math.sin(u);

            for (int s = 0; s <= sides; s++) {
                float v = (float) (s * 2.0 * Math.PI / sides);
                float cv = (float) Math.cos(v);
                float sv = (float) Math.sin(v);

                float x = (rOuter + rTube * cv) * cu;
                float y = rTube * sv;
                float z = (rOuter + rTube * cv) * su;

                vertices[vIndex] = x;
                vertices[vIndex + 1] = y;
                vertices[vIndex + 2] = z;

                normals[vIndex] = cv * cu;
                normals[vIndex + 1] = sv;
                normals[vIndex + 2] = cv * su;

                vIndex += 3;
            }
        }

        int numIndices = rings * sides * 6;
        short[] indices = new short[numIndices];
        int iIndex = 0;
        for (int r = 0; r < rings; r++) {
            for (int s = 0; s < sides; s++) {
                short cur = (short) (r * (sides + 1) + s);
                short next = (short) (r * (sides + 1) + (s + 1));
                short curBelow = (short) ((r + 1) * (sides + 1) + s);
                short nextBelow = (short) ((r + 1) * (sides + 1) + (s + 1));

                indices[iIndex++] = cur;
                indices[iIndex++] = curBelow;
                indices[iIndex++] = next;

                indices[iIndex++] = next;
                indices[iIndex++] = curBelow;
                indices[iIndex++] = nextBelow;
            }
        }

        return new Mesh(vertices, normals, indices);
    }

    /**
     * Creates a horizontal planar Quad for shadows, lasers, and track glow lines.
     */
    public static Mesh createQuad(float width, float height) {
        float w = width * 0.5f;
        float h = height * 0.5f;

        float[] vertices = {
                -w, 0.0f, -h,
                -w, 0.0f,  h,
                 w, 0.0f,  h,
                 w, 0.0f, -h
        };

        float[] normals = {
                0.0f, 1.0f, 0.0f,
                0.0f, 1.0f, 0.0f,
                0.0f, 1.0f, 0.0f,
                0.0f, 1.0f, 0.0f
        };

        short[] indices = {
                0, 1, 2,
                0, 2, 3
        };

        return new Mesh(vertices, normals, indices);
    }

    /**
     * Creates a vertical Billboard Quad for particles, laser barriers.
     */
    public static Mesh createVerticalQuad(float width, float height) {
        float w = width * 0.5f;
        float h = height * 0.5f;

        float[] vertices = {
                -w, -h, 0.0f,
                 w, -h, 0.0f,
                 w,  h, 0.0f,
                -w,  h, 0.0f
        };

        float[] normals = {
                0.0f, 0.0f, 1.0f,
                0.0f, 0.0f, 1.0f,
                0.0f, 0.0f, 1.0f,
                0.0f, 0.0f, 1.0f
        };

        short[] indices = {
                0, 1, 2,
                0, 2, 3
        };

        return new Mesh(vertices, normals, indices);
    }
}
